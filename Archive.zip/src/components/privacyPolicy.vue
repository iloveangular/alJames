<template>
    <main>
        <section class="privacy-policy">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="title">
                            <h2><span>Privacy Policy</span></h2>
                            <hr>
                            <p>When visiting our web sites, requesting information or placing an order to Agent Legal, you supply us with personal confidential information. Agent Legal uses the information you provide about yourself only for internal procedures and other information-keeping records, as well as to complete your requests or instructions. We respect your privacy and we do not share this information with third parties, except to the extent necessary to complete your orders or requests.</p>
                            <p>If you provide us with personal data, such as address, e-mail, telephone or fax numbers, demographic or client identifications, this information will not be disclosed by us, nor will it be shared, sold or announced to any third party, unless we inform you about it and always subject to your consent, or unless we are required to do so in virtue of legal regulations.</p>
                            <p>This information, like the information about your business activities and transactions, will be kept by us in accordance with our usual strict security standards and confidentiality principals.</p>
                            <p>Our web sites may provide the facility to register in order to gain enhanced access privileges or in order to purchase products or services. If you register, it is your responsibility to maintain the confidentiality of your password. On no account should you disclose your password to anyone else. Accounts and password information may be stored in cookies. Please consult the help files for your browser for more information related to cookies. Our website uses cookies, and you are deemed to consent to the use of cookies by using the website. You can turn off the use of cookies in your web browser. You agree to indemnify and hold us harmless for any loss or damage we may incur resulting from breach of this clause.</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>
</template>