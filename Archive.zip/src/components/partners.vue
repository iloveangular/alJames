<template>
        <main class="partners">
            <div class="cover">
                <div class="container">
                    <div class="row">
                        <div class="col-md-6 image"><img src="src/assets/images/starting-business-partners.png"></div>
                        <div class="col-md-6">
                            <h1>Agent Legal Partner Program</h1>
                            <p>We offer global partnership opportunities across a wide range of corporate services. Our aim is to build and maintain long–term mutually beneficial partnerships with professional intermediaries, corporate service providers and regular customers from around the globe.</p>
                        </div>
                    </div>
                </div>
                <div class="call-to-action"><span>Apply now to join our partner program</span>
                    <a href="#form">
                        <button class="btn btn-green">Sign Up</button>
                    </a>
                </div>
            </div>
            <section class="tabs tabs-partners">
                <div class="container">
                    <ul class="nav nav-tabs" role="tablist">
                        <li class="active" role="presentation"><a href="#home" aria-controls="home" role="tab" data-toggle="tab">Why Choose Us</a></li>
                        <li role="presentation"><a href="#profile" aria-controls="profile" role="tab" data-toggle="tab">How it
                            Works</a></li>
                        <li role="presentation"><a href="#messages" aria-controls="messages" role="tab" data-toggle="tab">Who
                            Can Join</a></li>
                    </ul>
                    <!-- Tab panes-->
                    <div class="tab-content">
                        <div class="tab-pane active" id="home" role="tabpanel">
                            <div class="content">
                                <h2>Why Choose Us</h2>
                                <div class="row">
                                    <div class="col-md-9">
                                        <ul>
                                            <li>Over 10,000 customers served globally</li>
                                            <li>International presence in more than 60 countries</li>
                                            <li>One-Stop-Shop for your business needs</li>
                                            <li>Affordable fees with no hidden costs</li>
                                            <li>Personal service and detailed assistance every step of the way</li>
                                            <li>Multilingual support - English, French, Greek, Russian, Romanian, Bulgarian...</li>
                                        </ul>
                                    </div>
                                    <div class="col-md-3 featured-image"><img src="src/assets/images/why-starting-business.png"></div>
                                </div>
                                <h2>Advantages of our Partner Program</h2>
                                <div class="row">
                                    <div class="col-md-9">
                                        <ul>
                                            <li>Discount codes for online purchases</li>
                                            <li>Ability to resell our services and set your own margin</li>
                                            <li>Priority processing of client applications</li>
                                            <li>Tailor-made cooperation</li>
                                            <li>Free advice and support services</li>
                                            <li>High level of privacy and confidentiality</li>
                                            <li>No partnership registration or application fees</li>
                                            <li>View and monitor online purchases</li>
                                            <li>We handle all the paperwork and keep you up-to-date</li>
                                        </ul>
                                    </div>
                                    <div class="col-md-3 featured-image"><img src="src/assets/images/partner-program.png"></div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane" id="profile" role="tabpanel">
                            <div class="content"><img src="src/assets/images/partner-discount.png">
                                <h3>Partner Code</h3>
                                <p>STARTING BUSINESS Partner Program allows you to use your partner code at www.startingbusiness.com. A partner code is a discount code which you can use to get a discount when making purchases online.</p>
                                <p>Discount rates apply for each purchase after the total spent threshold is crossed:</p>
                                <ul>
                                    <li><strong>Over USD 5,000 =</strong><span class="green">5% discount</span></li>
                                    <li><strong>Over USD 10,000 =</strong><span class="green">8% discount</span></li>
                                    <li><strong>Over USD 15,000 =</strong><span class="green">10% discount</span></li>
                                    <li><strong>Over USD 20,000 =</strong><span class="green">15% discount</span></li>
                                </ul>
                                <p>The percentage of the discount code can be increased depending on the number of clients or high volumes of business you provide to STARTING BUSINESS.</p>
                                <h4>Please note:</h4>
                                <ul>
                                    <li>The discount code must be entered during checkout to receive the offer.</li>
                                    <li>The discount code is linked exclusively to your email, therefore cannot be shared with third parties.
                                    </li>
                                    <li>Discount codes apply to the subtotal (sum of items prices for all items in this order) and the total discount cannot be more than a subtotal.</li>
                                    <li>Discount codes cannot be applied for Special Offer and Packages items.</li>
                                    <li>Discount codes are not exchangeable for cash and cannot be used to pay taxes, government fees, shipping and handling charges.</li>
                                </ul><img src="src/assets/images/tailored-partner.png">
                                <h3>Tailor-Made Cooperation</h3>
                                <p>If you are a professional service provider or a member of a reputable law or accounting firm and looking for tailor-made cooperation, we are happy to offer our exclusive partnership that suits your business needs. The tailor-made program is designed to help our partners successfully deal with today’s global market challenges.</p>
                                <p>Each of your orders will be reviewed and considered by our Business Development team and will be negotiated on a case-by-case basis for mutual beneficial relationship. Our flexible tailor-made options include, but not limited to:</p>
                                <ul>
                                    <li>receipt of payment for referred clients</li>
                                    <li>variety of revenue schemes</li>
                                    <li>signing of exclusive partnership agreement</li>
                                    <li>offer services to your clients with STARTING BUSINESS as your silent provider</li>
                                    <li>other attractive conditions of cooperation.</li>
                                </ul>
                            </div>
                        </div>
                        <div class="tab-pane" id="messages" role="tabpanel">
                            <div class="content">
                                <h2>Who can Join</h2>
                                <p>Our Partner Program is suitable for the following types of business professionals:</p>
                                <div class="row margin-30">
                                    <div class="col-md-1"></div>
                                    <div class="col-md-2 block"><img src="src/assets/images/tax-advisors.png">
                                        <h3>Tax Advisors &amp; Chartered Accountants</h3></div>
                                    <div class="col-md-2 block"><img src="src/assets/images/lawyers.png">
                                        <h3>Lawyers &amp; Legal Practitioners</h3></div>
                                    <div class="col-md-2 block"><img src="src/assets/images/consultants.png">
                                        <h3>Business Consultants</h3></div>
                                    <div class="col-md-2 block"><img src="src/assets/images/financial.png">
                                        <h3>Financial Companies</h3></div>
                                    <div class="col-md-2 block"><img src="src/assets/images/trade.png">
                                        <h3>Trade Associations</h3></div>
                                    <div class="col-md-1"></div>
                                </div>
                                <p>If you are a regular customer you might be eligible for discounts and benefits at Starting Business. <a href="/#/contact">Contact us</a> today to find out more.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <section class="partners-form" id="form">
                <div class="container">
                    <h2>Apply to Join our Partner Program</h2>
                    <p>Complete the form below to find out if you're eligible for our partner program. Once we approve your application, you will receive an email with your Agent Legal partner code that will allow you to place orders at your discounted rate.</p>
                    <div class="row" v-if="!sent">
                        <div class="col-md-6 col-md-push-3">
                          <form id="contactForm" class="contactFormPartners">
                          <div class="form-group"><span>Full Name *</span>
                                    <input class="form-control partnerName" name="name" placeholder="" type="text" required>
                                </div>
                                <div class="form-group"><span>Company Name</span>
                                    <input class="form-control partnerCompany" name="companyName" placeholder="" type="text">
                                </div>
                                <div class="form-group"><span>Company Website</span>
                                    <input class="form-control partnerWebsite" name="companyWebsite" placeholder="" type="text">
                                </div>
                                <div class="form-group"><span>Email *</span>
                                    <input class="form-control partnerEmail" name="email" placeholder="" type="text" required>
                                </div>
                                <div class="form-group"><span>Telephone *</span>
                                    <input class="form-control partnerPhone" name="phone" placeholder="" type="text" required>
                                </div>
                                <div class="form-actions">
                                    <button class="btn btn-green submitPartner">Submit</button>
                                </div>
                          </form>
                        </div>
                    </div>
                    <div class="row" v-if="sent">
                        <div class="col-lg-12">
                            <h3 style="text-align: center;">Thanks for your signing up on our Partners list!</h3>
                        </div>
                    </div>
                </div>
            </section>
        </main>
</template>
<script>
    import axios from 'axios'
    import * as config from '@/scripts/main'

    export default {
        data() {
            return {
                sent: ''
            }
        },
        mounted() {
            var vm = this;
            console.log(vm.sent);
            $(document).ready(function () {
                if(localStorage.getItem('partnerSigned')) {
                    vm.sent = true;
                }
                function submitForm() {
                    console.log('hey there');
                    $.ajax({
                        type: "GET",
                        url: config.url + 'partners',
                        data: {
                            "name": $(".partnerName").val(),
                            "companyName": $(".partnerCompany").val(),
                            "companyWebsite": $(".partnerWebsite").val(),
                            "email": $(".partnerEmail").val(),
                            "phone": $(".partnerPhone").val()
                        },
                        success: function (data) {
                            vm.sent = true;
                            location.href = '/#/partners#';
                            localStorage.setItem('partnerSigned', true);
                        },
                        error: function (data) {
                            console.log(data);
                            vm.sent = false;
                        }
                    })
                }
                // Validation
              $("#contactForm").validate({
                rules: {
                  "name": {
                    required: true,
                    minlength: 5
                  },
                  "phone": {
                    required: true,
                    digits: true
                  },
                  "email": {
                    required: true,
                    email: true
                  }
                },
                messages: {
                  "name": {
                    required: "Please, enter a name"
                  },
                  "phone": {
                    required: "Please, enter a phone"
                  },
                  "email": {
                    required: "Please, enter an email",
                    email: "Email is invalid"
                  }
                },
                submitHandler: function (form) { // for demo
                  submitForm();
                  return false; // for demo
                }
              });
            })
        }

    }
</script>
