<template>
    <main>
        <section class="privacy-policy">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="title">
                            <h2><span>Terms of Business</span></h2>
                            <hr>
                            <ol>
                                <li>DEFINITIONS</li>
                                <ol>
                                    <li>
                                        “Agent Legal” means Agent Legal, LLC. (Registered address: 4643 S. ULSTER STREET, Denver, CO 80237) and any of its branches, agents or associated companies throughout the world and all of its directors, officers, employees, agents, consultants and successors in title.
                                    </li>
                                    <li>
                                        “Agent Legal’s Officers” means any person (as hereinafter defined), firm or company nominated by Agent Legal who may from time to time be appointed as director, alternate director, secretary, alternate secretary, partner, accountant, trustee, nominee, protector, bank account signatory, administrator, registered agent, provider of a registered office or address of the Entity (as hereinafter defined).
                                    </li>
                                    <li>
                                        “Client” means the Beneficial Owner(s) of an Entity (as hereinafter defined) and/or any person who has requested Agent Legal to provide Services (as hereinafter defined), or any other person who has agreed to pay for Services, or who has previously paid for Services, and/or any person on whose behalf and for whose benefit the Services are to be provided, also including any person(s) authorized to represent the Client (Authorized Person(s) as hereinafter defined), and in the case of more than one person all such persons jointly and severally.
                                    </li>
                                    <li>
                                        “Authorized Person” means the person who is authorized by the Client for and in his name and on his behalf to give instructions to Agent Legal as if these were given by the Client himself.
                                    </li>
                                    <li>
                                        "Person" means any natural person over the age of 18 years old or a legal person, organization, incorporated firm or other body, incorporated or unincorporated
                                    </li>
                                    <li>
                                        “Entity” means any company, trust, partnership, foundation or any other legal entity established and/or administered by Agent Legal at the request and/or on behalf of the Client.
                                    </li>
                                    <li>
                                        “Services” means formation of any company, trust, partnership, foundation or any other Entity, provision of the registered office, registered agent, company secretary, director, officer, shareholder, maintenance of corporate records and accounts, preparation and filing of financial statements and annual returns and/or any other management or administration services or any type of service requested by the Client as contained in the directory of services of Agent Legal, or specified in advertising materials of Agent Legal, or on their websites and/or any other service(s) ordered/ requested/accepted by the Client.
                                    </li>
                                    <li>
                                        “Fee Schedule” means a fee schedule for services issued from time to time by Agent Legal;
                                    </li>
                                    <li>
                                        “Business Day” means a day on which Agent Legal is ordinarily open to carry on business;
                                    </li>
                                    <li>
                                        “Terms and Conditions” means these Terms and Conditions or such other new terms and conditions as may from time to time be published on Agent Legal’s websites and shall be deemed to include such other conditions which Agent Legal may from time to time advise to the Client or publish on Agent Legal’s websites. These Terms and Conditions apply to all Agent Legal’s Clients and effectively constitute binding Agreement between the Client and Agent Legal.
                                    </li>
                                    <li>
                                        “Web site” “Website” or “Site” means the web site you are browsing when you clicked on a link to these Terms and Conditions of Business, including all subsidiary pages.
                                    </li>
                                </ol>
                                <li>UNACCEPTABLE BUSINESS AND BUSINESS REQUIRING SPECIAL AUTHORIZATION</li>
                                <ol>
                                    <li>
                                        “Illegal Activities” means any activity designated anywhere in the world to be illegal or criminal, including activities related to terrorism, drug trafficking, money laundering, receiving the proceeds of criminal activities or trading with such countries, which may from time to time be subject to any embargo imposed by the Security Council of the United Nations, the European Union or similar international organizations.
                                    </li>
                                    <li>
                                        “Prohibited Activities” means activities currently not approved by Agent Legal, including activities related to: trade, distribution or manufacturing of arms, weapons, munitions; mercenary or contract soldiering; security and riot control equipment; any device that could lead to the abuse of human rights or be utilized for torture; technical surveillance or bugging equipment; industrial espionage; dangerous or hazardous biological, chemical or nuclear materials including equipment or machinery used to manufacture, handle or dispose of such materials; human or animal organs; the abuse of animals or use of animals for any scientific or product testing; genetic material; adoption agencies, including surrogate motherhood; the abuse of human rights; pornography; drug paraphernalia; pyramid sales; religious cults and their charities; business activities, which by the laws and regulations of the country of formation of the Entity are subject to licensing and which are conducted without obtainment of a license (“Licensable Activities” as hereinafter defined); any other activity, which, in the opinion of Agent Legal, may damage the reputation of Agent Legal or that of the country of formation of the Entity.
                                    </li>
                                    <li>
                                        “Prohibited Persons” means persons black listed under the laws of any country for whatever reason or who are legally disqualified from, or incapable of, being party to a contract; persons who are non discharged bankrupts or have been imprisoned or found guilty of any criminal offence; government officials or politicians; persons who have been proven to act in a fraudulent or dishonest manner in any civil proceedings or who are resident in a country subject to any international restrictions or embargos, including those imposed by the Security Council of the United Nations, the European Union or other international organizations.
                                    </li>
                                    <li>
                                        “Licensable Activities” means any activity that requires a license or authorization granted by a relevant authority in any jurisdiction. Such activities include, but not limited to: provision of financial services involving trading/brokerage in foreign exchange, financial and commodity-based derivative instruments and other securities; offering investment advice to public; insurance and banking business; operation and administration of collective investment schemes and mutual funds; payment processing services; money exchange, money transmission or money brokering; asset management; safe custody services; gaming, gambling and lotteries.
                                    </li>
                                </ol>
                                <li>CLIENT REQUESTS &amp; INSTRUCTIONS</li>
                                <ol>
                                    <li>
                                        Agent Legal provide a range of professional Services including, but not limited to: company formation; corporate structuring; administration and management; provision of bookkeeping and accountancy services; advisory and consultancy services.
                                    </li>
                                    <li>
                                        In providing the Services, Agent Legal shall always act solely on requests or instructions received from the Client and shall never act in their own discretion, except when being under legal obligation to act otherwise.
                                    </li>
                                    <li>
                                        Agent Legal shall be willing to consider and entertain requests and instructions of the Client.
                                    </li>
                                    <li>
                                        All instructions or requests for action shall be transmitted to Agent Legal by the Client in writing. In case of reasonable doubt, Agent Legal may request the Client to provide additional verification of any such request or instruction. Agent Legal shall not be liable for any loss or damage due to their failure to act until such instruction or request is verified to their satisfaction.
                                    </li>
                                    <li>
                                        Agent Legal may, in their absolute discretion, agree to act upon Client’s request or instruction given otherwise than in writing, in which case, however, Agent Legal shall not be liable for any misunderstanding or error occasioned in processing such request or instruction acted upon in good faith.
                                    </li>
                                    <li>
                                        Agent Legal may, in their absolute discretion, refuse to comply with any request or instruction received from the Client, if such request/instruction or implementation thereof would, in the opinion of Agent Legal, be dishonest, incorrect, malicious or contravene any applicable law or regulation or expose Agent Legal or any of their Officers or employees to any personal liability or risk of prosecution in any jurisdiction, or otherwise be illegal.
                                    </li>
                                    <li>
                                        Agent Legal may refuse to act on any request or instruction, which appears to be incomplete, unclear, ambiguous, conflicting or of unclear authenticity, and shall not be liable for any loss or damage for their failure to act until such deficiencies are rectified to their satisfaction.
                                    </li>
                                    <li>
                                        In the absence of gross negligence on the part of Agent Legal, the Client shall bear all risk of loss and damage caused by any instruction, request or information not being sent or received, by any such communication being incomplete, illegible, ambiguous or in error, or by any instructions or communication being issued by unauthorized third parties unlawfully purporting to represent the Client.
                                    </li>
                                    <li>
                                        On their websites and in advertising materials, Agent Legal may provide information, which is related to various products and services offered by Agent Legal. Such information does not purport to be legal or tax advice and shall not be taken to constitute such advice or used or relied upon by the Client as such. The Client shall take independent advice on any matter relating to the Entity and any Services provided by Agent Legal that may affect or concern the Client and his personal affairs.
                                    </li>
                                </ol>
                                <li>ADMINISTRATION OF ENTITIES</li>
                                <ol>
                                    <li>
                                        The Client irrevocably agrees that, if the Entity is a limited liability company and Agent Legal’s Officers are members or directors of that company, or the Entity is a Partnership and Agent Legal’s Officers are members of that partnership, or the Entity is a trust and Agent Legal’s Officers are trustees or protectors of that trust, or the Entity is a foundation and Agent Legal’s Officers are founders or council members, due to non-payment of Agent Legal’s fees and/or any other fees related to the Entity for more than sixty (60) days, Agent Legal shall without being obliged to give notice to the Client, may take such steps as they shall, in their absolute discretion, consider appropriate which include, without limitation, the following: having the Entity struck off, dissolved or liquidated; or resigning all or any of the Agent Legal’s Officers; or transferring all or any of the shares, capital or assets or liabilities of the Entity into the name of the Client; or appointing the Client as director, officer, manager, trustee or protector or founder or council member of the Entity; or take such other action as Agent Legal shall, in their absolute discretion, consider appropriate.
                                    </li>
                                    <li>
                                        Agent Legal shall keep confidential all documents, communications and information attained from the Client, unless prior written consent has been given by the Client permitting the contrary. This confidentiality will not be applicable where:
                                    </li>
                                    <ol>
                                        <li>
                                            Agent Legal may be obliged by order of a court or a competent authority to disclose evidence and information to courts or authorities in connection with the Client or Client’s Entity’s affairs. Where Agent Legal receive such a disclosure order, Agent Legal shall, unless prohibited by law or by the terms of such order, notify the Client of same.
                                        </li>
                                        <li>
                                            Any demand is made or action is taken by a third party against the Entity, or where any other circumstances arise which may, in the opinion of Agent Legal, necessitate an action to be taken regarding the affairs of the Entity in order to protect the best interests of the Client, the Entity or Agent Legal, and if in such circumstances Agent Legal are unable to obtain clear, adequate and lawful instructions from the Client, then Agent Legal shall be entitled to proceed in any way it may deem fit, reasonable or appropriate under the circumstances.
                                        </li>
                                    </ol>
                                    <li>
                                        In providing the Services, Agent Legal may share information concerning the Client, his Entity or its business activities with other firms or companies associated with Agent Legal, their auditors and legal advisors, and the Client agrees to Agent Legal’s making such disclosures. All information, correspondence, records and data related to the Entity and held by Agent Legal on any computer system is solely Agent Legal’s property and for its sole use and neither the Client, nor the Entity nor anyone else acting for or on their behalf shall have any right of access thereto or control over that information, correspondence, records or data. Agent Legal have the right to retain ownership and keep copies of all such information, correspondence, records and data for their sole use. The provision of this clause shall remain in full force and effect notwithstanding the Terms and Conditions ceasing to apply.
                                    </li>
                                    <li>
                                        In the event of the relocation involving the change of the Client’s Entity’s registered address and registered office, Agent Legal shall give the Client twenty (20) calendar days notice of such change. Agent Legal shall not be responsible for any associated costs incurred by the Client as a result of such change.
                                    </li>
                                    <li>
                                        Where Agent Legal has been requested by the Client to provide shareholders, directors or other Officers for his Entity, Agent Legal may, subject to Clause 2(b) hereof, accede to such request and designate any person to any such office or position, including any subsequent change, replacement or removal of such appointees, who may be either a physical or legal person.
                                    </li>
                                    <li>
                                        Nothing in these Terms and Conditions will make Agent Legal liable or responsible for any commercial decision that the Client has made in respect of the Entity or its business activities.
                                    </li>
                                    <li>
                                        In the event that (i) any claim, demand or action is made against the Entity for payment of any sums due either to Agent Legal or to a third party, including without limitation any taxes, duties, fees, government or state levies, and such payment has not been made; or (ii) Agent Legal require assistance or information from the Client and has been unable to obtain such assistance or information; or (iii) the Client is in breach of any of his obligations or undertakings contained in these Terms and Conditions, then Agent Legal may undertake any of the following:
                                    </li>
                                    <ol>
                                        <li>
                                            refrain from any action or activity whatsoever, be it in relation to a particular matter or to the Entity; or
                                        </li>
                                        <li>
                                            utilize any assets of the Entity or means available to Agent Legal or to the Entity towards a defense against such claim, demand or action, or satisfaction of such claim, demand or action; or
                                        </li>
                                        <li>
                                            take any other course of action that Agent Legal may, in their absolute discretion, consider appropriate to protect themselves and the Entity.
                                        </li>
                                    </ol>
                                    <p>
                                        Agent Legal shall not be liable for any loss or damage to the Client or his Entity incurred in the circumstances described in this clause.</p>
                                    <li>
                                        If the Client is in breach of any of his obligations or undertakings assumed under these Terms and Conditions and fails to remedy such breach within 14 calendar days following a notice issued by Agent Legal, then Agent Legal may undertake any of the following:
                                    </li>
                                    <ol>
                                        <li>resign from providing any or all of the Services;</li>
                                        <li>commence proceedings to wind-up and liquidate the Entity;</li>
                                        <li>
                                            utilize any assets of the Entity towards remediation of the Client’s breach.
                                        </li>
                                    </ol>
                                    <p>
                                        No responsibility or liability shall attach to Agent Legal in connection with or arising out of any action or inaction taken in accordance with the provisions of this paragraph.</p>
                                </ol>
                                <li>LIMITATION OF LIABILITY</li>
                                <ol>
                                    <li>
                                        Agent Legal expressly disclaims any liability to the Client, the Entity and any third party associated with them for any damage or loss to any of them arising from the establishment, acquisition or operation of the Entity and/or the provision of Services by or to the Client, the Entity or any other person.
                                    </li>
                                    <li>
                                        Agent Legal will not be liable (whether in contract, tort or otherwise, including breach of statutory duty) in connection with the provision of Services for any consequential loss however incurred, including without limitation loss of profit, business or anticipated savings of the Client.
                                    </li>
                                    <li>
                                        Agent Legal will not incur any liability for any failure to comply with any request, instruction or order of the Client, which is not received, or which is incomplete, ambiguous and illegible or lacks, in the opinion of Agent Legal, authority on the part of the person giving it.
                                    </li>
                                    <li>
                                        Agent Legal will not be liable for the acts or omissions or negligence of any person or entity which is appointed or designated as director, shareholder, officer, employee, agent, individual, trustee, manager, signatory or holder of a power of attorney with respect to the Entity or other person or body associated with the Entity.
                                    </li>
                                </ol>
                                <li>INDEMNITY</li>
                                <ol>
                                    <li>
                                        The Client shall at all times indemnify and keep Agent Legal and its Officers and employees harmless and indemnified:
                                    </li>
                                    <ol>
                                        <li>
                                            against all actions, suits, proceedings, claims, demands, costs, charges, expenses and liabilities (including legal fees), which may arise or be incurred, commenced or threatened against Agent Legal and/or their officers in relation to the Entity or the Client’s instructions;
                                        </li>
                                        <li>
                                            in respect of any failure by Agent Legal to comply, wholly or partially, with any instruction, order or request made by the Client, or any errors or incomplete instructions or requests received by Agent Legal from the Client;
                                        </li>
                                        <li>
                                            in respect of any penalties, fines, fees or other liabilities incurred by the Client and/or the Entity related to the Entity and/or to the Services.
                                        </li>
                                    </ol>
                                    <li>
                                        This indemnity is without prejudice to any other indemnity and/or remedy in favour of Agent Legal and/or their officers, employees, agents or successors. The termination of this Agreement or any Service provided by Agent Legal shall not relieve the Client of his obligations to indemnify Agent Legal.
                                    </li>
                                </ol>
                                <li>WARRANTIES</li>
                                <p>
                                    The Client undertakes, warrants and solemnly declares with Agent Legal that he/she:</p>
                                <p></p>
                                <ol>
                                    <li>
                                        has full legal capacity and is of sound mind, memory and understanding to enter into an agreement with Agent Legal in accordance with these Terms and Conditions and to receive the Services;
                                    </li>
                                    <li> is not bankrupt;</li>
                                    <li>
                                        has no criminal records and there is no criminal proceeding pending against the Client in any jurisdiction;
                                    </li>
                                    <li>
                                        is not engaged in any illegal or prohibited activity as defined in section 2 , subparagraphs 1 and 2, of this Terms of Business that may directly or indirectly cause harm to the reputation of Agent Legal;
                                    </li>
                                    <li>will comply with these Terms and Conditions;</li>
                                    <li>
                                        agree that Agent Legal may (but shall not be obliged to) rely on communications received from the Client in determining what steps Agent Legal are required to take in administering his Entity or providing the Services;
                                    </li>
                                    <li>
                                        will pay, in full, any personal or corporate taxes that may become due as a result of the establishment and operation of the Entity.
                                    </li>
                                </ol>
                                <li>CLIENT’S OBLIGATIONS AND UNDERTAKINGS</li>
                                <ol>
                                    <li>
                                        The Client is obliged to immediately inform Agent Legal of the nature of the activities and business of the Entity and seek Agent Legal‘s written consent before making any changes to those activities.
                                    </li>
                                    <li>
                                        Agent Legal are required by law to have certain due diligence (Know-Your-Customer) documents in place. The Client expressly agrees and accepts to disclose and provide to Agent Legal such documents or any other information that Agent Legal may consider necessary or desirable both at the Client acceptance stage and on an on-going basis in order that Agent Legal could meet their legal obligations.
                                    </li>
                                    <li>
                                        To enable Agent Legal at all times to contact the Client, the Client is obliged to provide full details of, and promptly notify Agent Legal of, any changes to his residential address, telephone and fax numbers and email address in addition to any business or other contact address as may have been provided by him.
                                    </li>
                                    <li>
                                        The Client undertakes not to give any instruction, order or make any request to Agent Legal, which would cause Agent Legal to breach the law of any country.
                                    </li>
                                    <li>
                                        The Client shall provide Agent Legal with such information, assistance and cooperation as Agent Legal may, in their absolute discretion, require for the purpose of provision of Services. Agent Legal will not be responsible for any consequences that may arise from Client’s failure to comply with this requirement, which may incur additional fees that will be charged to and become payable by the Client.
                                    </li>
                                    <li>
                                        The Client hereby confirms that any asset introduced to the Entity has been lawfully introduced and has not been derived from Illegal Activities.
                                    </li>
                                    <li>
                                        The Client undertakes not to cause Agent Legal and/or their officers, to be engaged or involved directly or indirectly in any unlawful, Illegal or Prohibited Activities or used for any unlawful purpose.
                                    </li>
                                    <li>
                                        The Client is obliged to give Agent Legal at least 30 days’ advance written notice of his intention to discontinue the Services.
                                    </li>
                                    <li>
                                        The Client is obliged to give Agent Legal written prior notice when seeking to change the beneficial ownership of the Entity.
                                    </li>
                                    <li>
                                        The Client shall settle without delay any sum due to Agent Legal including fees, disbursements and expenses incurred by Agent Legal in connection with the Entity and/or with the provision of the Services.
                                    </li>
                                </ol>
                                <li>CLIENT’S OBLIGATIONS WHERE Agent Legal PROVIDE OFFICERS OR NOMINEE SERVICES</li>
                                <ol>
                                    <li>
                                        Agent Legal shall at all times be willing to consider and entertain Client’s requests to provide Officers or nominee services to the Client’s Entity subject to acceptance, restrictions and limitations provided for in these Terms and Conditions.
                                    </li>
                                    <li>Where Agent Legal provide Officers or nominee services, the Client must
                                        <ol>
                                            <li>
                                                at all times, upon request of Agent Legal, pay Agent Legal such sums as may be required to enable the Entity discharge, in full, any liabilities (including Agent Legal’s fees);
                                            </li>
                                            <li>
                                                upon written request of Agent Legal immediately provide information to enable Agent Legal to prepare annual or other statutory returns, financial or other statements in relation to the Entity;
                                            </li>
                                            <li>
                                                immediately advise Agent Legal in writing of all legal proceedings, claims and demands made or threatened against the Entity or Agent Legal;
                                            </li>
                                            <li>
                                                keep and maintain and upon request deliver to Agent Legal accurate financial and business records.
                                            </li>
                                        </ol>
                                    </li>
                                    <li>
                                        The Client acknowledges and understands that Officers or nominees my incur personal liabilities if certain statutory obligations relating to the Entity are not complied with and that compliance with such statutory obligations is dependent on the Client promptly paying fees and responding to requests for information. If the Client fails to pay fees when due or called for, or respond promptly to requests for information, the Officers or nominees shall be entitled to resign from their offices, and the Client hereby irrevocably and unconditionally appoints Agent Legal its attorney and agent for the purpose of appointing the Client as Officer in Agent Legal’s place.
                                    </li>
                                    <li>
                                        The Officers or nominees provided by Agent Legal to act as Directors in a Client’s Entity shall be acting exclusively upon instructions received from the Client and therefore will not be involved in a day-to-day operations and/or signing of contracts for or on behalf of the Entity, or act as a guarantor on behalf of the Client and/or the Entity.
                                    </li>
                                    <li>
                                        An Officer or nominee acting as Director in the Client’s Entity, may entertain the Client’s request to sign contracts and/or various documents subject to the provisions contained in 9(f) hereof and for a fee to be agreed from time to time with the Client.
                                    </li>
                                    <li>
                                        An Officer or nominee acting as Director in the Client’s Entity, will not place their signature on agreement, or document, which refer to any loans or encumbrance made on behalf of the Entity or any other agreement or document, which in the opinion of the Officer or nominee, constitute high risk and may create liability to the Entity, Agent Legal and Officers or Nominees acting as Directors in the Client’s Entity.
                                    </li>
                                </ol>
                                <li>ADDITIONAL OBLIGATIONS WHERE Agent Legal PROVIDE REGISTERED OFFICE ADDRESS</li>
                                <ol>
                                    <li>
                                        Where Agent Legal provides the registered office and registered address to the Entity, the Client will at no time make any reference to the registered office address in an advertisement, public announcement, promotion, or a website, without prior written consent of Agent Legal. At no time the Client may present such registered office and registered address as the location of the actual business operations of the Entity, its commercial records, management and control.
                                    </li>
                                </ol>
                                <li>FEES AND REFUNDS</li>
                                <ol>
                                    <li>Fees and refunds are governed by the <a href="/terms-of-payment"
                                                                                title="Terms of Payment">Terms of Payment</a>, which are incorporated by reference and should be read together with this Terms and Conditions of Business.
                                    </li>
                                </ol>
                                <li>FORCE MAJEURE</li>
                                <ol>
                                    <li>
                                        Agent Legal shall not be liable for any delay or failure to perform any of their obligations in connection with the supply of any goods or services ordered by the Client through the website or otherwise, if the delay or failure results from events or circumstances outside our reasonable control, including but not limited to acts of God, strikes, lock outs, accidents, war, fire or failure of any communications, telecommunications or computer system, and Agent Legal shall be entitled to a reasonable extension of their obligations to the Client (to the extent Agent Legal owe any such obligations) should a force Majeure event occur.
                                    </li>
                                    <li>
                                        If a Force Majeure event to which this clause applies shall occur, Agent Legal agree to notify the Client as soon as practicable. If the Force Majeure event continues for more than 14 days, either party shall have the right to cancel the Agreement and where services have been paid for in advance, but have not been rendered, the Client will be entitled to a refund from the date of cancellation for all such services.
                                    </li>
                                </ol>
                                <li>CESSATION OF SERVICES</li>
                                <ol>
                                    <li>
                                        Agent Legal will be entitled by written notice to cease provision of Services to the Client, if:
                                    </li>
                                    <li>
                                        the Client is, in the reasonable opinion of Agent Legal, in breach of these Terms and Conditions, provided such breach is not remedied within fifteen (15) days following the written notice given by Agent Legal;
                                    </li>
                                    <li>
                                        it comes to the attention of Agent Legal that the Entity is being used for activities, which were not declared and referred to in the application submitted by the Client to Agent Legal during incorporation of the Entity, and/or these activities are considered to be Illegal or Prohibited as defined in clauses 2(a) and 2(b) of these Terms and Conditions;
                                    </li>
                                    <li>
                                        in the event that any legal proceedings are commenced against the Entity or the Client.
                                    </li>
                                    <li>
                                        In any of the circumstances described in 12(a) above, Agent Legal reserve the right to proceed according to Clause 4(a) hereof without further liability on the part of Agent Legal.
                                    </li>
                                </ol>
                                <li>NOTICES</li>
                                <p></p>
                                <ol>
                                    <li>
                                        Any notice required to be served pursuant to these Terms and Conditions may be served by DHL express post, email or facsimile to the address and as per details last known to the parties. A notice shall be deemed served:
                                        <ul>
                                            <li>within five (5) business days if sent by DHL express post;</li>
                                            <li>
                                                by facsimile or email, if confirmed by a successful transmission report.
                                            </li>
                                        </ul>
                                    </li>
                                </ol>
                                <li>MISCELLANEOUS</li>
                                <ol>
                                    <li>
                                        References to one gender include all genders and references to the singular include the plural and vice versa.
                                    </li>
                                    <li>
                                        This Agreement incorporates by reference other provisions applicable to use of the websites, products and services of Agent Legal, including, but not limited to, <a
                                            href="/privacy-policy" title="Privacy Policy">Privacy Policy</a>,<a
                                            href="/disclaimer" title="Disclaimer">Disclaimer</a>, <a
                                            href="/terms-of-payment">Terms of Payment </a>and <a href="/terms-of-use"
                                                                                                 title="Terms of Use">Terms of Use</a>, which are published on the websites.
                                    </li>
                                    <li>
                                        No variations of these Terms and Conditions shall be binding on the parties unless agreed in writing.
                                    </li>
                                    <li>
                                        If at any time any provision of these Terms and Conditions is held invalid or unenforceable under any applicable law, the remainder of same shall remain in full force and effect.
                                    </li>
                                    <li>
                                        These Terms and Conditions supersede all previous written or verbal communications or representations between Agent Legal and the Client.
                                    </li>
                                    <li>
                                        Nothing in these Terms and Conditions suggests a legal partnership or agency between Agent Legal and the Client.
                                    </li>
                                    <li>
                                        The Client shall take his own independent advice on any matter relating to the Entity and any Services provided by Agent Legal, that may concern the Client, or his Entity, or personal affairs and shall not rely on any representations (whether written, verbal, expressed, implied or otherwise) made by Agent Legal, their Officers or employees. As it is the Client’s responsibility to seek expert legal advice, Agent Legal shall not accept any liability to the Client, his Entity or any third party for any claims, damage or loss arising out or in connection with the use of any of the Services.
                                    </li>
                                    <li>
                                        No failure or delay in exercising by a party hereto of any power or right conferred by these Terms and Conditions shall operate as a waiver of such power or right, unless otherwise agreed in writing.
                                    </li>
                                </ol>
                                <li>GOVERNING LAW &amp; JURISDICTION</li>
                                <ol>
                                    <li>
                                        These Terms and Conditions shall be governed by and construed in all respects in accordance with the laws of Colorado. Any dispute that arises concerning the interpretation of these Terms and Conditions shall be resolved in the courts of Colorado.
                                    </li>
                                </ol>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>
</template>