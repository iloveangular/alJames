<template>
    <main class="faq">
        <section>
            <div class="container">
                <div class="row">
                    <div class="col-xs-12">
                        <h2>FAQs</h2>
                        <p>
                            Agent Legal offer comprehensive consultancy on all related areas of international company formation and bank account opening. We have provided a detailed overview of frequently asked questions below as a useful resource for clients seeking specific information.</p>
                    </div>
                </div>
            </div>
        </section>
        <section class="tabbing-verticallay tabbing-banks-verticallay">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12">
                        <h3>Everything you need to know</h3>
                        <div class="tab">
                            <button class="tablinks active" id="defaultOpen" onclick="openCity(event, 'ShopFaqsTab')">
                                Shop FAQs
                            </button>
                            <button class="tablinks" onclick="openCity(event, 'CompanyFaqsTab')">Company Formation FAQs
                            </button>
                            <button class="tablinks" onclick="openCity(event, 'BankAFaqsTab')">Bank Account FAQs
                            </button>
                            <button class="tablinks" onclick="openCity(event, 'TrademarkRFaqsTab')">
                                Trademark Registration FAQs
                            </button>
                        </div>
                        <div class="tabcontent" id="ShopFaqsTab" style="display: block;">
                            <div>
                                <div class="panel-group" id="accordion">
                                    <!-- - Start1 --->
                                    <div class="panel panel-default">
                                        <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                             data-parent="#accordion" data-target="#collapse1" aria-expanded="false">
                                            <h4 class="panel-title">How do I pay for my order?</h4></div>
                                        <div class="panel-collapse collapse" id="collapse1" aria-expanded="false"
                                             style="height: 1px;">
                                            <div class="panel-body">
                                                <p>
                                                    All credit/debit card transactions on our website are processed through PayPal or secure and trusted payment gateways managed by leading banks. You can enter your credit or debit card information during the checkout process to complete the payment. You can also pay for your order using your PayPal account.</p>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- - End1 --->
                                    <!-- - Start2 --->
                                    <div class="panel panel-default">
                                        <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                             data-parent="#accordion" data-target="#collapse2" aria-expanded="false">
                                            <h4 class="panel-title">
                                                Is it safe to use my debit/credit card on www.agentlegal.com?</h4></div>
                                        <div class="panel-collapse collapse" id="collapse2" aria-expanded="false">
                                            <div class="panel-body">
                                                <p>
                                                    Your online debit/credit card transactions are protected by advanced security solutions based on international standards managed by the leading banks and trusted payment processors.</p>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- - End2 --->
                                    <!-- - Start3 --->
                                    <div class="panel panel-default">
                                        <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                             data-parent="#accordion" data-target="#collapse3" aria-expanded="false">
                                            <h4 class="panel-title">
                                                Will I be charged any additional fees by your company after I've used your service?</h4>
                                        </div>
                                        <div class="panel-collapse collapse" id="collapse3" aria-expanded="false">
                                            <div class="panel-body">
                                                <p>
                                                    Never. The only exception is if you utilize our Registered Agent Services or Annual Maintenance Fees. Note that we always notify you via email at least 30 days before we process any renewal payment which gives you plenty of time to cancel any recurring service.</p>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- - End3 --->
                                    <!-- - Start4 --->
                                    <div class="panel panel-default">
                                        <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                             data-parent="#accordion" data-target="#collapse4" aria-expanded="false">
                                            <h4 class="panel-title">How is my order processed?</h4></div>
                                        <div class="panel-collapse collapse" id="collapse4" aria-expanded="false">
                                            <div class="panel-body">
                                                <p>Your order will be processed in the following steps:</p>
                                                <p><b>Step 1.</b>
                                                    During checkout you will be asked to either log in or register. If you are a new member you must register in order to proceed. Once you have registered and paid for your order, you can view the current status of your transactions by going to ‘My Transactions’ in your account profile.
                                                </p>
                                                <p><b>Step 2.</b>
                                                    Once we receive your payment, Agent Legal will send you an email acknowledging the details of your order.
                                                </p>
                                                <p>
                                                    Step 3. In ‘My Transactions’ you will find all your transactions with the relevant application forms. If you have purchased Company Formation and/or a Bank Account please fill in and submit the relevant Application form, with personal documentation, by email to support@agentlegal.com. Once submitted, our Corporate Executives will review your Application and contact you within the next business day. Please take note that our business hours are from EET 8:00 a.m. - EET 18:00 p.m. Monday – Friday.</p>
                                                <p><b>Step 4.</b>
                                                    If your Application is incomplete or invalid, our Corporate Executives will advise you of the reasons and what is now required. Sometimes we need further information, which is needed to properly determine whether your application meets requirements of the legislation/bank. Once confirmed, you must print and sign the Application form and send it by post along with other required documentation.
                                                </p>
                                                <p><b>Step 5.</b>
                                                    Once your company is registered, originals of all corporate documentation will be sent to you as scanned copies by e-mail and then couriered by DHL to your designated address.
                                                </p>
                                                <p>
                                                    As soon as your bank account opening order is accepted and processed by the bank, you will receive your bank account details and contact details of your assigned bank official via e-mail. The password, user ID, digipass, credit/debit card and other devices will be forwarded to you by the bank direct or with assistance of Agent Legal.</p>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- - End4 --->
                                    <!-- - Start4 --->
                                    <div class="panel panel-default">
                                        <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                             data-parent="#accordion" data-target="#collapse5" aria-expanded="false">
                                            <h4 class="panel-title">
                                                Where can I download my purchased templates of documents or forms??</h4>
                                        </div>
                                        <div class="panel-collapse collapse" id="collapse5" aria-expanded="false">
                                            <div class="panel-body">
                                                <p>
                                                    Once you purchase your business documents, you can download them by going to ’My Transactions’ in your account profile.</p>
                                                <p>
                                                    Please note that the document will be available for 30 days from the day of purchase.</p>
                                                <p>If you didn’t have time to download the document you can always <a
                                                        href="http://dev.mishatechnologies.com/#">contact us</a>
                                                    and we will provide you with the document.</p>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- - End4 --->
                                </div>
                            </div>
                        </div>
                        <div class="tabcontent" id="CompanyFaqsTab" style="display: none;">
                            <div>
                                <div class="panel-group" id="accordion1">
                                    <!-- - Start6 --->
                                    <div class="panel panel-default">
                                        <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                             data-parent="#accordion1" data-target="#collapse6" aria-expanded="false">
                                            <h4 class="panel-title">
                                                How is my order for the bank account opening processed?</h4></div>
                                        <div class="panel-collapse collapse" id="collapse6" aria-expanded="false">
                                            <div class="panel-body">
                                                <p>Your order will be processed in the following steps:</p>
                                                <p><strong>Step 1.</strong>
                                                    During checkout you will be asked to either log in or register. If you are a new member you must register in order to proceed. Once you have registered and paid for your order, you can view the current status of your transactions by going to ‘My Transactions’ in your account profile.
                                                </p>
                                                <p><strong>Step 2.</strong>
                                                    Once we receive your payment, Agent Legal will send you an email acknowledging the details of your order.
                                                </p>
                                                <p><strong>Step 3.</strong>
                                                    In ‘My Transactions’ you will find all your transactions with the relevant application forms. If you have purchased Company Formation and/or a Bank Account please fill in and submit the relevant Application form, with personal documentation, by email to <a
                                                            href="mailto:support@agentlegal.com">support@agentlegal.com</a>. Once submitted, our Corporate Executives will review your Application and contact you within the next business day. Please take note that our business hours are from EET 8:00 a.m. - EET 18:00 p.m. Monday – Friday.
                                                </p>
                                                <p><strong>Step 4.</strong>
                                                    If your Application is incomplete or invalid, our Corporate Executives will advise you of the reasons and what is now required. Sometimes we need further information, which is needed to properly determine whether your application meets requirements of the legislation/bank. Once confirmed, you must print and sign the Application form and send it by post along with other required documentation.
                                                </p>
                                                <p><strong>Step 5.</strong>
                                                    Once your company is registered, originals of all corporate documentation will be sent to you as scanned copies by e-mail and then couriered by DHL to your designated address.
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- - End6 --->
                                    <!-- - Start7 --->
                                    <div class="panel panel-default">
                                        <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                             data-parent="#accordion1" data-target="#collapse7" aria-expanded="false">
                                            <h4 class="panel-title">How long does it take to set up a company?</h4>
                                        </div>
                                        <div class="panel-collapse collapse" id="collapse7" aria-expanded="false">
                                            <div class="panel-body">
                                                <p>
                                                    We begin processing your order as soon as the online purchase is completed. Processing times will vary depending on the company type and jurisdiction chosen. Usually International Business companies can be registered within several working days (depending on jurisdiction chosen) upon receipt of all required documentation and information. Please note, that we need up to 10 working days for legalization of the corporate documents and delivery the new company package to you by courier.</p>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- - End7 --->
                                    <!-- - Start8 --->
                                    <div class="panel panel-default">
                                        <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                             data-parent="#accordion1" data-target="#collapse8" aria-expanded="false">
                                            <h4 class="panel-title">
                                                Can Agent Legal help me choose the type of company and jurisdiction?</h4>
                                        </div>
                                        <div class="panel-collapse collapse" id="collapse8" aria-expanded="false">
                                            <div class="panel-body">
                                                <p>
                                                    Our Corporate Executives can provide you with guidance on the types of companies and jurisdictions, choice of company name, formation procedures and other requirements. If you are unsure about any aspect of forming a company, you should consider seeking professional advice from our corporate executives. If you have any questions or need additional information, contact our Live Chat Support or <a
                                                        href="mailto:support@agentlegal.com">send us an e-mail.</a></p>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- - End8 --->
                                    <!-- - Start9 --->
                                    <div class="panel panel-default">
                                        <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                             data-parent="#accordion1" data-target="#collapse9" aria-expanded="false">
                                            <h4 class="panel-title">
                                                What information do I need to supply for my company formation?</h4>
                                        </div>
                                        <div class="panel-collapse collapse" id="collapse9" aria-expanded="false">
                                            <div class="panel-body">
                                                <p>
                                                    Please provide the following documents for all Directors, Shareholders, Beneficial Owners, Authorized Signatories:</p>
                                                <p><b>Notarized copy of valid passport.</b>
                                                    The passport must be signed and signature must match the signature in the application form. The photograph must be clear and of good quality.
                                                </p>
                                                <p><b>Original or Certified copy of utility bill / bank statement</b>(as verification of residential address, dated within 3 months); the household utility bill (e.g. gas, electricity, water or fixed line telephone <b>but not a mobile phone bill</b>) or bank, building society or credit card statement as proof of address. It must be no more than 3 months old and show your name and current address. P.O. Box is not accepted.
                                                </p>
                                                <p><b>Original or certified copy of Banker’s reference letter</b>
                                                    (dated within 3 months). You can request the Reference Letter from the bank where you hold an account. The reference letter should include confirmation that the relationship has been maintain for longer than 2 years and the business affairs are run satisfactorily.
                                                </p>
                                                <p><b>In cases where shareholders and/or directors are corporate bodies, full apostilled set of corporate documents will be required:</b>
                                                    Certificate of Incorporation, List of Directors, Shareholders, Secretary, Share Certificate, copy of ‘Declaration of Trust’ between nominee shareholder(s) and ultimate beneficial owner(s) (if applicable), Certificate of Good Standing (if the company has been operating for 12 months or more); Notarized copy of a valid passport, utility bill and the reference letter for each individual Director, Shareholder and Beneficial Owner.
                                                </p>
                                                <p><b>Completed and Sign Application form.</b>
                                                    The relevant Application Form you can find in ‘My Transactions’ of your account profile.
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- - End9 --->
                                    <!-- - Start10 --->
                                    <div class="panel panel-default">
                                        <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                             data-parent="#accordion1" data-target="#collapse10" aria-expanded="false">
                                            <h4 class="panel-title">What if chosen company name is not available?</h4>
                                        </div>
                                        <div class="panel-collapse collapse" id="collapse10" aria-expanded="false">
                                            <div class="panel-body">
                                                <p>
                                                    The name must not be already in use or be too similar to an existing company name or state a trading name. There are also restrictions on certain words and language and other pitfalls if your chosen name is too similar to a registered trademark. Therefore we require you to provide us with 3 name choices. If your first name choice is not available, we will check the availability of the second or third. As part of our review process we will advise you if a name is identical, allowing you to suggest alternatives.</p>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- - End10 --->
                                    <!-- - Start11 --->
                                    <div class="panel panel-default">
                                        <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                             data-parent="#accordion1" data-target="#collapse11" aria-expanded="false">
                                            <h4 class="panel-title">
                                                What do I receive upon registration of my company?</h4>
                                        </div>
                                        <div class="panel-collapse collapse" id="collapse11" aria-expanded="false">
                                            <div class="panel-body p-space-remove">
                                                <p>
                                                    Usually most International Business Companies use standard-format documents. However, the required set of documents may vary depending on the type of company and jurisdiction.</p>
                                                <p>
                                                    Upon registration of your company all corporate documentation will be sent to you as scanned copies by e-mail and couriered to your designated address:</p>
                                                <p>Official Certificate of Incorporation.</p>
                                                <p>Memorandum and Articles of Association.</p>
                                                <p>Appointment of First Directors.</p>
                                                <p>Register of Directors, Shareholders, Secretary.</p>
                                                <p>Share Certificate.</p>
                                                <p>Power of Attorney (if applicable).</p>
                                                <p>Declaration of Trust (if applicable).</p>
                                                <p>A Common Company seal.</p>
                                                <p>
                                                    The list of company documents might slightly differ from document to document, depending on chosen jurisdiction.</p>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- - End11 --->
                                    <!-- - Start12 --->
                                    <div class="panel panel-default">
                                        <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                             data-parent="#accordion1" data-target="#collapse12" aria-expanded="false">
                                            <h4 class="panel-title">How is my company documentation shipped?</h4></div>
                                        <div class="panel-collapse collapse" id="collapse12" aria-expanded="false">
                                            <div class="panel-body">
                                                <p>
                                                    All orders are shipped via DHL, in order to provide you with the best possibleservice.
                                                    <br>
                                                    Shipping and handling charges are calculated and added to each order at the point of payment.
                                                    <br>
                                                    Delivery time is usually estimated to 3-4 days but may vary depending on destination country.
                                                    <br>
                                                    We are not responsible for any delays in shipping due to natural disasters, strikes or events outside of our control.
                                                    <br>
                                                    A DHL tracking number will be provided once your documents have been sent.
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- - End12 --->
                                </div>
                            </div>
                        </div>
                        <div class="tabcontent" id="BankAFaqsTab" style="display: none;">
                            <div>
                                <div class="panel-group" id="accordion3">
                                    <!-- - Start13 --->
                                    <div class="panel panel-default">
                                        <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                             data-parent="#accordion3" data-target="#collapse13" aria-expanded="false">
                                            <h4 class="panel-title">
                                                How is my order for the bank account opening processed?</h4></div>
                                        <div class="panel-collapse collapse" id="collapse13" aria-expanded="false">
                                            <div class="panel-body">
                                                <p>Your order will be processed in the following steps:</p>
                                                <p><strong>Step 1.</strong>
                                                    During checkout you will be asked to either log in or register. If you are a new member you must register in order to proceed. Once you have registered and paid for your order, you can view the current status of your transactions by going to ‘My Transactions’ in your account profile.
                                                </p>
                                                <p><strong>Step 2.</strong>
                                                    Once we receive your payment, Agent Legal will send you an email acknowledging the details of your order.
                                                </p>
                                                <p><strong>Step 3.</strong>
                                                    In ‘My Transactions’ you will find all your transactions with the relevant application forms. If you have purchased Company Formation and/or a Bank Account please fill in and submit the relevant Application form, with personal documentation, by email to <a
                                                            href="mailto:support@agentlegal.com">support@agentlegal.com</a>. Once submitted, our Corporate Executives will review your Application and contact you within the next business day. Please take note that our business hours are from EET 8:00 a.m. - EET 18:00 p.m. Monday – Friday.
                                                </p>
                                                <p><strong>Step 4.</strong>
                                                    If your Application is incomplete or invalid, our Corporate Executives will advise you of the reasons and what is now required. Sometimes we need further information, which is needed to properly determine whether your application meets requirements of the legislation/bank. Once confirmed, you must print and sign the Application form and send it by post along with other required documentation.
                                                </p>
                                                <p><strong>Step 5.</strong>
                                                    As soon as your bank account opening order is accepted and processed by the bank, you will receive your bank account details and contact details of your assigned bank official via e-mail. The password, user ID, digipass, credit/debit card and other devices will be forwarded to you by the bank direct or with assistance of Agent Legal.
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- - End13 --->
                                    <!-- - Start14 --->
                                    <div class="panel panel-default">
                                        <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                             data-parent="#accordion3" data-target="#collapse14" aria-expanded="false">
                                            <h4 class="panel-title">
                                                How long does it take to set up a bank account? </h4>
                                        </div>
                                        <div class="panel-collapse collapse" id="collapse14" aria-expanded="false">
                                            <div class="panel-body">
                                                <p>
                                                    We begin processing your order as soon as the online purchase is completed. Processing times vary depending on the bank requirements and jurisdiction chosen. Usually the bank account can be activated within 1 week upon receipt by the bank of all required documentation and information. You will be notified via email on the progress of your account opening.</p>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- - End14 --->
                                    <!-- - Start15 --->
                                    <div class="panel panel-default">
                                        <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                             data-parent="#accordion3" data-target="#collapse15" aria-expanded="false">
                                            <h4 class="panel-title">
                                                Do I need to visit the bank personally to open an account? </h4></div>
                                        <div class="panel-collapse collapse" id="collapse15" aria-expanded="false">
                                            <div class="panel-body">
                                                <p>
                                                    Most of the international banks we cooperate with do not require a personal visit and the account opening procedure may be completed remotely.</p>
                                                <p>
                                                    If a personal interview is required, we will arrange your meeting with the bank officer in the nearest branch or representative office.</p>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- - End15 --->
                                    <!-- - Start16 --->
                                    <div class="panel panel-default">
                                        <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                             data-parent="#accordion3" data-target="#collapse16" aria-expanded="false">
                                            <h4 class="panel-title">
                                                Will the bank account be opened automatically for my new company? </h4>
                                        </div>
                                        <div class="panel-collapse collapse" id="collapse16" aria-expanded="false">
                                            <div class="panel-body">
                                                <p>
                                                    No. If you choose the bank account opening option, we shall review your application along with personal documentation to see if it is complete and valid. The bank will then approve or decline the account, depending on how the nature of your business and other information provided by you fits with their business model. More than 90% of our cases have been approved by the bank.</p>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- - End16 --->
                                    <!-- - Start17 --->
                                    <div class="panel panel-default">
                                        <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                             data-parent="#accordion3" data-target="#collapse17" aria-expanded="false">
                                            <h4 class="panel-title">What does Bank’s pre-approval actually mean? </h4>
                                        </div>
                                        <div class="panel-collapse collapse" id="collapse17" aria-expanded="false">
                                            <div class="panel-body">
                                                <p>
                                                    When we receive a pre-approval confirmation from the bank regarding account opening, this means that the bank has collected all required initial information and standard set of documents on a person or company. Based on this collected information, the client qualifies for the bank account opening. If the bankers have any further questions to complete the processing of your requested account, they will <a
                                                        href="http://dev.mishatechnologies.com/contact_us">contact us</a>
                                                    for more details. Once the account is processed, approved and activated, you will have full access and will be able to send and receive payments.
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- - End17 --->
                                    <!-- - Start18 --->
                                    <div class="panel panel-default">
                                        <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                             data-parent="#accordion3" data-target="#collapse18" aria-expanded="false">
                                            <h4 class="panel-title">
                                                What happens if the bank refuses to open an account?  </h4></div>
                                        <div class="panel-collapse collapse" id="collapse18" aria-expanded="false">
                                            <div class="panel-body">
                                                <p>
                                                    Banks are entitled at their sole discretion to accept or reject applications to open an account, as such we will introduce you to the bank and guide through all account opening process, however we cannot guarantee that your account will be approved by the bank and successfully opened.</p>
                                                <p>
                                                    If the bank declines your personal or corporate account, we will evaluate the situation and offer alternate banking options. However, more than 90% of our cases have been approved by the bank.</p>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- - End18 --->
                                    <!-- - Start19 --->
                                    <div class="panel panel-default">
                                        <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                             data-parent="#accordion3" data-target="#collapse19" aria-expanded="false">
                                            <h4 class="panel-title">
                                                Can Agent Legal help me choose the bank and jurisdiction? </h4></div>
                                        <div class="panel-collapse collapse" id="collapse19" aria-expanded="false">
                                            <div class="panel-body">
                                                <p>
                                                    Our Corporate Executives can provide you with guidance on the bank requirements and products. However, we cannot advise you whether a bank is the best vehicle for your business. If you have any questions or need additional information, please contact our Live Chat Support or <a
                                                        href="mailto:support@agentlegal.com">send us an e-mail.</a></p>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- - End19 --->
                                    <!-- - Start20 --->
                                    <div class="panel panel-default">
                                        <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                             data-parent="#accordion3" data-target="#collapse20" aria-expanded="false">
                                            <h4 class="panel-title">
                                                What information do I need to supply for my corporate account opening? </h4>
                                        </div>
                                        <div class="panel-collapse collapse" id="collapse20" aria-expanded="false">
                                            <div class="panel-body">
                                                <p>
                                                    Please provide the following documents for all Directors, Shareholders, Beneficial Owners, Authorized Signatories:</p>
                                                <ul style="padding-left: 20px;">
                                                    <li><strong>Notarized copy of valid passport.</strong>
                                                        The passport must be signed and signature must match the signature in the application form. The photograph must be clear and of good quality.
                                                    </li>
                                                    <li>
                                                        <strong>Original or Certified copy of utility bill / bank statement</strong>
                                                        (as verification of residential address, dated within 3 months); the household utility bill (e.g. gas, electricity, water or fixed line telephone <strong>but not a mobile phone bill</strong>) or bank, building society or credit card statement as proof of address. It must be no more than 3 months old and show your name and current address. P.O. Box is not accepted.
                                                    </li>
                                                    <li>
                                                        <strong>Original or certified copy of Banker’s reference letter</strong>
                                                        (dated within 3 months). You can request the Reference Letter from the bank where you hold an account. The reference letter should include confirmation that the relationship has been maintain for longer than 2 years and the business affairs are run satisfactorily.
                                                    </li>
                                                    <li><strong>In cases where shareholders and/or directors are corporate bodies, full apostilled set of corporate documents will be required:</strong>
                                                        Certificate of Incorporation, List of Directors, Shareholders, Secretary, Share Certificate, copy of ‘Declaration of Trust’ between nominee shareholder(s) and ultimate beneficial owner(s) (if applicable), Certificate of Good Standing (if the company has been operating for 12 months or more); Notarized copy of a valid passport, utility bill and the reference letter for each individual Director, Shareholder and Beneficial Owner.
                                                    </li>
                                                    <li><strong>Personal CV.</strong>
                                                        In this document you should mention your work experience, qualifications, education, current place of work and position.
                                                    </li>
                                                    <li><strong>Completed and Sign Application form. </strong>The relevant Application Form you can find in ‘My Transactions’ of your account profile.
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- - End20 --->
                                    <!-- - Start21 --->
                                    <div class="panel panel-default">
                                        <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                             data-parent="#accordion3" data-target="#collapse21" aria-expanded="false">
                                            <h4 class="panel-title">
                                                What information do I need to supply for my personal account opening? </h4>
                                        </div>
                                        <div class="panel-collapse collapse" id="collapse21" aria-expanded="false">
                                            <div class="panel-body">
                                                <p>
                                                    Please provide the following documents for all Authorized Signatories:</p>
                                                <ul>
                                                    <li><strong>Notarized copy of valid passport. </strong>The passport must be signed and signature must match the signature in the application form. The photograph must be clear and of good quality.
                                                    </li>
                                                    <li>
                                                        <strong>Original or Certified copy of utility bill / bank statement </strong>(as verification of residential address, dated within 3 months); the household utility bill (e.g. gas, electricity, water or fixed line telephone <strong>but not a mobile phone bill</strong>) or bank, building society or credit card statement as proof of address. It must be no more than 3 months old and show your name and current address. P.O. Box is not accepted.
                                                    </li>
                                                    <li>
                                                        <strong>Original or certified copy of Banker’s reference letter </strong>(dated within 3 months). You can request the Reference Letter from the bank where you hold an account. The reference letter should include confirmation that the relationship has been maintain for longer than 2 years and the business affairs are run satisfactorily.
                                                    </li>
                                                    <li><strong>Personal CV.</strong>
                                                        In this document you should mention your work experience, qualifications, education, current place of work and position.
                                                    </li>
                                                    <li><strong>Completed and Sign Application form.</strong>
                                                        The relevant Application Form you can find in ‘My Transactions’ of your account profile.
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- - End21 --->
                                    <!-- - Start22 --->
                                    <div class="panel panel-default">
                                        <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                             data-parent="#accordion3" data-target="#collapse22" aria-expanded="false">
                                            <h4 class="panel-title">What is an EU Savings Tax Directive?</h4></div>
                                        <div class="panel-collapse collapse" id="collapse22" aria-expanded="false">
                                            <div class="panel-body">
                                                <p>
                                                    The European Union Savings Tax Directive (EUSTD) became effective on 1 July 2005 and applies to EU countries on interest received on savings instruments, deposit accounts, etc. Currently, it does not affect interest paid to companies. EUSTD is an agreement between the EU Member States to automatically exchange information between states about individuals who reside in one EU Member state but earn interest in another.</p>
                                                <p>
                                                    EUSTD applies to EU residents that receive interest on savings instruments, deposit accounts, etc. Currently, it does not affect interest paid to companies.</p>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- - End22 --->
                                    <!-- - Start23 --->
                                    <div class="panel panel-default">
                                        <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                             data-parent="#accordion3" data-target="#collapse23" aria-expanded="false">
                                            <h4 class="panel-title">
                                                Who can have an access to my personal or corporate account?</h4></div>
                                        <div class="panel-collapse collapse" id="collapse23" aria-expanded="false">
                                            <div class="panel-body">
                                                <p>
                                                    For security reasons we do not manage client accounts and do not offer such service. Once your account is finalized, the bank will forward all e-banking security devices, credit/debit cards and PINs directly to your correspondent address. Only authorized signatories will be able to access your personal or corporate account.</p>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- - End23 --->
                                    <!-- - Start24 --->
                                    <div class="panel panel-default">
                                        <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                             data-parent="#accordion3" data-target="#collapse24" aria-expanded="false">
                                            <h4 class="panel-title">What is a Digipass (Security Token)?</h4></div>
                                        <div class="panel-collapse collapse" id="collapse24" aria-expanded="false">
                                            <div class="panel-body">
                                                <p>
                                                    A Digipass or a Security Token is a small device that generates a unique code. It is used together with your User ID and passcode for making payments for the high level of security of Online Banking. If you are an authorized signatory and applied for online banking, then the bank will automatically send you one of these devices.</p>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- - End24 --->
                                </div>
                            </div>
                        </div>
                        <div class="tabcontent" id="TrademarkRFaqsTab" style="display: none;">
                            <div>
                                <div class="panel-group" id="accordion4">
                                    <!-- - Start25 --->
                                    <div class="panel panel-default">
                                        <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                             data-parent="#accordion4" data-target="#collapse25" aria-expanded="false">
                                            <h4 class="panel-title">How is my order processed?</h4></div>
                                        <div class="panel-collapse collapse" id="collapse25" aria-expanded="false">
                                            <div class="panel-body">
                                                <p><strong>Step 1.</strong>
                                                    Complete the online application form on the Trademark Page in four simple steps:
                                                </p>
                                                <ul style="padding-left: 20px;">
                                                    <li> Choose your Word Mark and/or Logo</li>
                                                    <li> Select the territory you wish to register your trademark</li>
                                                    <li> Select the Class of your business</li>
                                                    <li>
                                                        Fill out your details in the ‘Owner’s Details’ section proceed to checkout.
                                                    </li>
                                                </ul>
                                                <p><strong>Step 2.</strong>
                                                    Once we receive your payment, Agent Legal will send you an email acknowledging the details of your order. We will then start to process your order further.
                                                </p>
                                                <p><strong>Step 3.</strong>
                                                    Your Application Form along will be reviewed no later than 1 working day after receipt. If your Application is incomplete or invalid, our Corporate Executive will advise you of the reasons and what is now required.
                                                </p>
                                                <p><strong>Step 4.</strong>
                                                    Once your order is accepted and processed by the Trademark Authority, you will receive your Trademark Certificate via e-mail first and then the hard copy will be couriered to your designated address.
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- - End25 --->
                                    <!-- - Start26 --->
                                    <div class="panel panel-default">
                                        <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                             data-parent="#accordion4" data-target="#collapse26" aria-expanded="false">
                                            <h4 class="panel-title">What happens if my brand is not available?</h4>
                                        </div>
                                        <div class="panel-collapse collapse" id="collapse26" aria-expanded="false">
                                            <div class="panel-body">
                                                <p>
                                                    We will make propositions and offer solutions for changing the trademark scope in order to maximise your chances of succeeding with your application.</p>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- - End26 --->
                                    <!-- - Start27 --->
                                    <div class="panel panel-default">
                                        <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                             data-parent="#accordion4" data-target="#collapse27" aria-expanded="false">
                                            <h4 class="panel-title">What is a Community trademark (CTM)?</h4></div>
                                        <div class="panel-collapse collapse" id="collapse27" aria-expanded="false">
                                            <div class="panel-body">
                                                <p>
                                                    The CTM is a unified trademark registered in the European Union and grants an exclusive right in all member states of the EU. The CTM system is administered by the Office for Harmonization in the Internal Market (Trade Marks and Designs) (OHIM).</p>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- - End27 --->
                                    <!-- - Start28 --->
                                    <div class="panel panel-default">
                                        <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                             data-parent="#accordion4" data-target="#collapse28" aria-expanded="false">
                                            <h4 class="panel-title">
                                                Can you register trademarks in non-EU countries?</h4>
                                        </div>
                                        <div class="panel-collapse collapse" id="collapse28" aria-expanded="false">
                                            <div class="panel-body">
                                                <p>
                                                    Yes, we can assist with trademark registration in all member countries of the Madrid treaties and other non-member countries. If you wish to register your trademark outside of EU, please send us your request via our <a
                                                        href="http://dev.mishatechnologies.com/creditkazzamblog/index.php?module=contact_us">Contact Form</a>.
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- - End28 --->
                                    <!-- - Start29 --->
                                    <div class="panel panel-default">
                                        <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                             data-parent="#accordion4" data-target="#collapse29" aria-expanded="false">
                                            <h4 class="panel-title">Who can file a trademark application?</h4></div>
                                        <div class="panel-collapse collapse" id="collapse29" aria-expanded="false">
                                            <div class="panel-body">
                                                <p>
                                                    An application for a registered trademark can be filed by any individual, company or legal entity for use of representing goods or services in the market. Many people seek the assistance of a professional consultancy firm to facilitate the trademark search and registration application on their behalf as the process can be time consuming and complex depending on the jurisdictions you seek to register in.</p>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- - End29 --->
                                    <!-- - Start30 --->
                                    <div class="panel panel-default">
                                        <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                             data-parent="#accordion4" data-target="#collapse30" aria-expanded="false">
                                            <h4 class="panel-title">
                                                What are the main benefits of registering a trademark?</h4></div>
                                        <div class="panel-collapse collapse" id="collapse30" aria-expanded="false">
                                            <div class="panel-body">
                                                <p>
                                                    Registering a trademark will ensure that your business entities name, identity and logo are protected and it grants you exclusive ownership in your selected jurisdiction/s of registration. It also ensures that your entities brand, name or logo does not infringe other registered trademarks while granting you legal rights; and if need be, allowing you the ability to take legal action against any party that infringes your trademark rights. A registered trademark will instantly make competitors aware that the trademark is already taken and deter them from using a trademark that is similar.</p>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- - End30 --->
                                    <!-- - Start31 --->
                                    <div class="panel panel-default">
                                        <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                             data-parent="#accordion4" data-target="#collapse31" aria-expanded="false">
                                            <h4 class="panel-title">What can I register as a trade mark?</h4></div>
                                        <div class="panel-collapse collapse" id="collapse31" aria-expanded="false">
                                            <div class="panel-body">
                                                <p>
                                                    Any available name, slogan, logo, colour, smell, strap-line, buy-line, design, shape, etc. can be registered as a trademark.</p>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- - End31 --->
                                    <!-- - Start32 --->
                                    <div class="panel panel-default">
                                        <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                             data-parent="#accordion4" data-target="#collapse32" aria-expanded="false">
                                            <h4 class="panel-title">How long does a trademark last?</h4></div>
                                        <div class="panel-collapse collapse" id="collapse32" aria-expanded="false">
                                            <div class="panel-body">
                                                <p>
                                                    The validity of a registered trademark depends on the jurisdiction/s the mark is registered in. Typically, most jurisdictions adopt a validity period of 10 consecutive years from the date of registration. A registered trademark is also renewable every 10 years thereafter provided the mark was used in compliance with the appropriate trademark laws. Some jurisdictions stipulate that non use of a trademark for a specified period of time will result in removal and revocation of trademark rights from the owner.</p>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- - End32 --->
                                    <!-- - Start33 --->
                                    <div class="panel panel-default">
                                        <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                             data-parent="#accordion4" data-target="#collapse33" aria-expanded="false">
                                            <h4 class="panel-title">
                                                How long will a trade-mark application take to process?</h4></div>
                                        <div class="panel-collapse collapse" id="collapse33" aria-expanded="false">
                                            <div class="panel-body">
                                                <p>About 9 to 12 months depending on various factors.</p>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- - End33 --->
                                    <!-- - Start34 --->
                                    <div class="panel panel-default">
                                        <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                             data-parent="#accordion4" data-target="#collapse34" aria-expanded="false">
                                            <h4 class="panel-title">
                                                What is the difference between the notations TM, SM and ®?</h4></div>
                                        <div class="panel-collapse collapse" id="collapse34" aria-expanded="false">
                                            <div class="panel-body">
                                                <p>
                                                    The symbol TM adopted on an unregistered trademark while the symbol ® is used to demonstrate a registered trademark. In addition to trademarks are service marks denoted by the symbol SM.</p>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- - End34 --->
                                    <!-- - Start35 --->
                                    <div class="panel panel-default">
                                        <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                             data-parent="#accordion4" data-target="#collapse35" aria-expanded="false">
                                            <h4 class="panel-title">
                                                How often does my trademark need to be renewed?</h4>
                                        </div>
                                        <div class="panel-collapse collapse" id="collapse35" aria-expanded="false">
                                            <div class="panel-body">
                                                <p>
                                                    The renewal of a registered trademark will typically take place every 10 years as this is the most commonly used validity period of a trademark. The trademark owner will be notified up to 6 months prior to expiry of the trademark and then trademark renewal proceedings will be put into place, either by the owner or by a representative professional consultant. A registered trademark needs to be renewed for as long as it is required in commerce, as non-renewal will render the trademark redundant and without any legal protection.</p>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- - End35 --->
                                    <!-- - Start36 --->
                                    <div class="panel panel-default">
                                        <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                             data-parent="#accordion4" data-target="#collapse36" aria-expanded="false">
                                            <h4 class="panel-title">
                                                Do I have the right to sue where I believe my trademark rights are infringed?</h4>
                                        </div>
                                        <div class="panel-collapse collapse" id="collapse36" aria-expanded="false">
                                            <div class="panel-body">
                                                <p>
                                                    The first thing to note is that the infringing trademark must have caused a “likelihood of confusion” to the public and it must have caused harm to your registered trademark. The main factors taken into account for cases of trademark infringement are the similarity of the trademarks in question and the similar of the goods/services the marks represent. Under trademark law, all owners of a registered trademark have exclusive rights and are provided with a great deal of legal protection in cases of infringement or passing off.</p>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- - End36 --->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section class="tabbing-verticallay tabbing-verticallay-mobile" style="display: none;">
            <div class="container">
                <h1>Everything you need to know</h1>
                <div class="panel-group" id="accordion-20">
                    <div class="panel panel-default">
                        <div class="panel-heading accordion-toggle icon-hide collapsed" data-toggle="collapse"
                             data-parent="#accordion-20" data-target="#collapse08" aria-expanded="false">
                            <h4 class="panel-title">Shop FAQs</h4></div>
                        <div class="panel-collapse collapse" id="collapse08" aria-expanded="false" style="height: 0px;">
                            <div class="panel-body">
                                <div>
                                    <div class="panel-group" id="1accordion">
                                        <!-- - Start1 --->
                                        <div class="panel panel-default">
                                            <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                                 data-parent="#1accordion" data-target="#collapse-20"
                                                 aria-expanded="false">
                                                <h4 class="panel-title">How do I pay for my order?</h4></div>
                                            <div class="panel-collapse collapse" id="collapse-20" aria-expanded="false">
                                                <div class="panel-body">
                                                    <p>
                                                        All credit/debit card transactions on our website are processed through PayPal or secure and trusted payment gateways managed by leading banks. You can enter your credit or debit card information during the checkout process to complete the payment. You can also pay for your order using your PayPal account.</p>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- - End1 --->
                                        <!-- - Start2 --->
                                        <div class="panel panel-default">
                                            <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                                 data-parent="#1accordion" data-target="#collapse-21"
                                                 aria-expanded="false">
                                                <h4 class="panel-title">
                                                    Is it safe to use my debit/credit card on www.startingbusiness.com?</h4>
                                            </div>
                                            <div class="panel-collapse collapse" id="collapse-21" aria-expanded="false">
                                                <div class="panel-body">
                                                    <p>
                                                        Your online debit/credit card transactions are protected by advanced security solutions based on international standards managed by the leading banks and trusted payment processors.</p>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- - End2 --->
                                        <!-- - Start3 --->
                                        <div class="panel panel-default">
                                            <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                                 data-parent="#1accordion" data-target="#collapse-22"
                                                 aria-expanded="false">
                                                <h4 class="panel-title">
                                                    Will I be charged any additional fees by your company after I've used your service?</h4>
                                            </div>
                                            <div class="panel-collapse collapse" id="collapse-22" aria-expanded="false">
                                                <div class="panel-body">
                                                    <p>
                                                        Never. The only exception is if you utilize our Registered Agent Services or Annual Maintenance Fees. Note that we always notify you via email at least 30 days before we process any renewal payment which gives you plenty of time to cancel any recurring service.</p>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- - End3 --->
                                        <!-- - Start4 --->
                                        <div class="panel panel-default">
                                            <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                                 data-parent="#1accordion" data-target="#collapse-23"
                                                 aria-expanded="false">
                                                <h4 class="panel-title">How is my order processed?</h4></div>
                                            <div class="panel-collapse collapse" id="collapse-23" aria-expanded="false">
                                                <div class="panel-body">
                                                    <p>Your order will be processed in the following steps:</p>
                                                    <p><b>Step 1.</b>
                                                        During checkout you will be asked to either log in or register. If you are a new member you must register in order to proceed. Once you have registered and paid for your order, you can view the current status of your transactions by going to ‘My Transactions’ in your account profile.
                                                    </p>
                                                    <p><b>Step 2.</b>
                                                        Once we receive your payment, Agent Legal will send you an email acknowledging the details of your order.
                                                    </p>
                                                    <p>
                                                        Step 3. In ‘My Transactions’ you will find all your transactions with the relevant application forms. If you have purchased Company Formation and/or a Bank Account please fill in and submit the relevant Application form, with personal documentation, by email to support@agentlegal.com. Once submitted, our Corporate Executives will review your Application and contact you within the next business day. Please take note that our business hours are from EET 8:00 a.m. - EET 18:00 p.m. Monday – Friday.</p>
                                                    <p><b>Step 4.</b>
                                                        If your Application is incomplete or invalid, our Corporate Executives will advise you of the reasons and what is now required. Sometimes we need further information, which is needed to properly determine whether your application meets requirements of the legislation/bank. Once confirmed, you must print and sign the Application form and send it by post along with other required documentation.
                                                    </p>
                                                    <p><b>Step 5.</b>
                                                        Once your company is registered, originals of all corporate documentation will be sent to you as scanned copies by e-mail and then couriered by DHL to your designated address.
                                                    </p>
                                                    <p>
                                                        As soon as your bank account opening order is accepted and processed by the bank, you will receive your bank account details and contact details of your assigned bank official via e-mail. The password, user ID, digipass, credit/debit card and other devices will be forwarded to you by the bank direct or with assistance of Agent Legal.</p>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- - End4 --->
                                        <!-- - Start4 --->
                                        <div class="panel panel-default">
                                            <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                                 data-parent="#1accordion" data-target="#collapse-25"
                                                 aria-expanded="false">
                                                <h4 class="panel-title">
                                                    Where can I download my purchased templates of documents or forms??</h4>
                                            </div>
                                            <div class="panel-collapse collapse" id="collapse-25" aria-expanded="false">
                                                <div class="panel-body">
                                                    <p>
                                                        Once you purchase your business documents, you can download them by going to ’My Transactions’ in your account profile.</p>
                                                    <p>
                                                        Please note that the document will be available for 30 days from the day of purchase.</p>
                                                    <p>
                                                        If you didn’t have time to download the document you can always <a
                                                            href="http://dev.mishatechnologies.com/#">contact us</a>
                                                        and we will provide you with the document.</p>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- - End4 --->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="panel panel-default">
                        <div class="panel-heading accordion-toggle icon-hide collapsed" data-toggle="collapse"
                             data-parent="#accordion-20" data-target="#collapse-09" aria-expanded="false">
                            <h4 class="panel-title">Company Formation FAQs</h4></div>
                        <div class="panel-collapse collapse" id="collapse-09" aria-expanded="false">
                            <div class="panel-body">
                                <div>
                                    <div class="panel-group" id="2accordion">
                                        <!-- - Start6 --->
                                        <div class="panel panel-default">
                                            <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                                 data-parent="#2accordion" data-target="#collapse-26"
                                                 aria-expanded="false">
                                                <h4 class="panel-title">
                                                    How is my order for the bank account opening processed?</h4></div>
                                            <div class="panel-collapse collapse" id="collapse-26" aria-expanded="false">
                                                <div class="panel-body">
                                                    <p>Your order will be processed in the following steps:</p>
                                                    <p><strong>Step 1.</strong>
                                                        During checkout you will be asked to either log in or register. If you are a new member you must register in order to proceed. Once you have registered and paid for your order, you can view the current status of your transactions by going to ‘My Transactions’ in your account profile.
                                                    </p>
                                                    <p><strong>Step 2.</strong>
                                                        Once we receive your payment, Agent Legal will send you an email acknowledging the details of your order.
                                                    </p>
                                                    <p><strong>Step 3.</strong>
                                                        In ‘My Transactions’ you will find all your transactions with the relevant application forms. If you have purchased Company Formation and/or a Bank Account please fill in and submit the relevant Application form, with personal documentation, by email to <a
                                                                href="mailto:support@agentlegal.com">support@agentlegal.com</a>. Once submitted, our Corporate Executives will review your Application and contact you within the next business day. Please take note that our business hours are from EET 8:00 a.m. - EET 18:00 p.m. Monday – Friday.
                                                    </p>
                                                    <p><strong>Step 4.</strong>
                                                        If your Application is incomplete or invalid, our Corporate Executives will advise you of the reasons and what is now required. Sometimes we need further information, which is needed to properly determine whether your application meets requirements of the legislation/bank. Once confirmed, you must print and sign the Application form and send it by post along with other required documentation.
                                                    </p>
                                                    <p><strong>Step 5.</strong>
                                                        Once your company is registered, originals of all corporate documentation will be sent to you as scanned copies by e-mail and then couriered by DHL to your designated address.
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- - End6 --->
                                        <!-- - Start7 --->
                                        <div class="panel panel-default">
                                            <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                                 data-parent="#2accordion" data-target="#collapse-27"
                                                 aria-expanded="false">
                                                <h4 class="panel-title">How long does it take to set up a company?</h4>
                                            </div>
                                            <div class="panel-collapse collapse" id="collapse-27" aria-expanded="false">
                                                <div class="panel-body">
                                                    <p>
                                                        We begin processing your order as soon as the online purchase is completed. Processing times will vary depending on the company type and jurisdiction chosen. Usually International Business companies can be registered within several working days (depending on jurisdiction chosen) upon receipt of all required documentation and information. Please note, that we need up to 10 working days for legalization of the corporate documents and delivery the new company package to you by courier.</p>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- - End7 --->
                                        <!-- - Start8 --->
                                        <div class="panel panel-default">
                                            <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                                 data-parent="#2accordion" data-target="#collapse-28"
                                                 aria-expanded="false">
                                                <h4 class="panel-title">
                                                    Can Agent Legal help me choose the type of company and jurisdiction?</h4>
                                            </div>
                                            <div class="panel-collapse collapse" id="collapse-28" aria-expanded="false">
                                                <div class="panel-body">
                                                    <p>
                                                        Our Corporate Executives can provide you with guidance on the types of companies and jurisdictions, choice of company name, formation procedures and other requirements. If you are unsure about any aspect of forming a company, you should consider seeking professional advice from our corporate executives. If you have any questions or need additional information, contact our Live Chat Support or <a
                                                            href="mailto:support@agentlegal.com">send us an e-mail.</a>
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- - End8 --->
                                        <!-- - Start9 --->
                                        <div class="panel panel-default">
                                            <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                                 data-parent="#2accordion" data-target="#collapse-29"
                                                 aria-expanded="false">
                                                <h4 class="panel-title">
                                                    What information do I need to supply for my company formation?</h4>
                                            </div>
                                            <div class="panel-collapse collapse" id="collapse-29" aria-expanded="false">
                                                <div class="panel-body">
                                                    <p>
                                                        Please provide the following documents for all Directors, Shareholders, Beneficial Owners, Authorized Signatories:</p>
                                                    <p><b>Notarized copy of valid passport.</b>
                                                        The passport must be signed and signature must match the signature in the application form. The photograph must be clear and of good quality.
                                                    </p>
                                                    <p>
                                                        <b>Original or Certified copy of utility bill / bank statement</b>(as verification of residential address, dated within 3 months); the household utility bill (e.g. gas, electricity, water or fixed line telephone <b>but not a mobile phone bill</b>) or bank, building society or credit card statement as proof of address. It must be no more than 3 months old and show your name and current address. P.O. Box is not accepted.
                                                    </p>
                                                    <p><b>Original or certified copy of Banker’s reference letter</b>
                                                        (dated within 3 months). You can request the Reference Letter from the bank where you hold an account. The reference letter should include confirmation that the relationship has been maintain for longer than 2 years and the business affairs are run satisfactorily.
                                                    </p>
                                                    <p><b>In cases where shareholders and/or directors are corporate bodies, full apostilled set of corporate documents will be required:</b>
                                                        Certificate of Incorporation, List of Directors, Shareholders, Secretary, Share Certificate, copy of ‘Declaration of Trust’ between nominee shareholder(s) and ultimate beneficial owner(s) (if applicable), Certificate of Good Standing (if the company has been operating for 12 months or more); Notarized copy of a valid passport, utility bill and the reference letter for each individual Director, Shareholder and Beneficial Owner.
                                                    </p>
                                                    <p><b>Completed and Sign Application form.</b>
                                                        The relevant Application Form you can find in ‘My Transactions’ of your account profile.
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- - End9 --->
                                        <!-- - Start10 --->
                                        <div class="panel panel-default">
                                            <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                                 data-parent="#2accordion" data-target="#collapse-30"
                                                 aria-expanded="false">
                                                <h4 class="panel-title">
                                                    What if chosen company name is not available?</h4></div>
                                            <div class="panel-collapse collapse" id="collapse-30" aria-expanded="false">
                                                <div class="panel-body">
                                                    <p>
                                                        The name must not be already in use or be too similar to an existing company name or state a trading name. There are also restrictions on certain words and language and other pitfalls if your chosen name is too similar to a registered trademark. Therefore we require you to provide us with 3 name choices. If your first name choice is not available, we will check the availability of the second or third. As part of our review process we will advise you if a name is identical, allowing you to suggest alternatives.</p>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- - End10 --->
                                        <!-- - Start11 --->
                                        <div class="panel panel-default">
                                            <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                                 data-parent="#2accordion" data-target="#collapse-31"
                                                 aria-expanded="false">
                                                <h4 class="panel-title">
                                                    What do I receive upon registration of my company?</h4></div>
                                            <div class="panel-collapse collapse" id="collapse-31" aria-expanded="false">
                                                <div class="panel-body p-space-remove">
                                                    <p>
                                                        Usually most International Business Companies use standard-format documents. However, the required set of documents may vary depending on the type of company and jurisdiction.</p>
                                                    <p>
                                                        Upon registration of your company all corporate documentation will be sent to you as scanned copies by e-mail and couriered to your designated address:</p>
                                                    <p>Official Certificate of Incorporation.</p>
                                                    <p>Memorandum and Articles of Association.</p>
                                                    <p>Appointment of First Directors.</p>
                                                    <p>Register of Directors, Shareholders, Secretary.</p>
                                                    <p>Share Certificate.</p>
                                                    <p>Power of Attorney (if applicable).</p>
                                                    <p>Declaration of Trust (if applicable).</p>
                                                    <p>A Common Company seal.</p>
                                                    <p>
                                                        The list of company documents might slightly differ from document to document, depending on chosen jurisdiction.</p>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- - End11 --->
                                        <!-- - Start12 --->
                                        <div class="panel panel-default">
                                            <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                                 data-parent="#2accordion" data-target="#collapse-31"
                                                 aria-expanded="false">
                                                <h4 class="panel-title">How is my company documentation shipped?</h4>
                                            </div>
                                            <div class="panel-collapse collapse" id="collapse-31" aria-expanded="false">
                                                <div class="panel-body">
                                                    <p>
                                                        All orders are shipped via DHL, in order to provide you with the best possibleservice.
                                                        <br>
                                                        Shipping and handling charges are calculated and added to each order at the point of payment.
                                                        <br>
                                                        Delivery time is usually estimated to 3-4 days but may vary depending on destination country.
                                                        <br>
                                                        We are not responsible for any delays in shipping due to natural disasters, strikes or events outside of our control.
                                                        <br>
                                                        A DHL tracking number will be provided once your documents have been sent.
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- - End12 --->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="panel panel-default">
                        <div class="panel-heading accordion-toggle icon-hide" data-toggle="collapse"
                             data-parent="#accordion-20" data-target="#collapse-10" aria-expanded="true">
                            <h4 class="panel-title">Bank Account FAQs</h4></div>
                        <div class="panel-collapse collapse in" id="collapse-10" aria-expanded="true">
                            <div class="panel-body">
                                <div>
                                    <div class="panel-group" id="3accordion">
                                        <!-- - Start13 --->
                                        <div class="panel panel-default">
                                            <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                                 data-parent="#3accordion" data-target="#collapse-32"
                                                 aria-expanded="false">
                                                <h4 class="panel-title">
                                                    How is my order for the bank account opening processed?</h4></div>
                                            <div class="panel-collapse collapse" id="collapse-32" aria-expanded="false">
                                                <div class="panel-body">
                                                    <p>Your order will be processed in the following steps:</p>
                                                    <p><strong>Step 1.</strong>
                                                        During checkout you will be asked to either log in or register. If you are a new member you must register in order to proceed. Once you have registered and paid for your order, you can view the current status of your transactions by going to ‘My Transactions’ in your account profile.
                                                    </p>
                                                    <p><strong>Step 2.</strong>
                                                        Once we receive your payment, Agent Legal will send you an email acknowledging the details of your order.
                                                    </p>
                                                    <p><strong>Step 3.</strong>
                                                        In ‘My Transactions’ you will find all your transactions with the relevant application forms. If you have purchased Company Formation and/or a Bank Account please fill in and submit the relevant Application form, with personal documentation, by email to <a
                                                                href="mailto:support@agentlegal.com">support@agentlegal.com</a>. Once submitted, our Corporate Executives will review your Application and contact you within the next business day. Please take note that our business hours are from EET 8:00 a.m. - EET 18:00 p.m. Monday – Friday.
                                                    </p>
                                                    <p><strong>Step 4.</strong>
                                                        If your Application is incomplete or invalid, our Corporate Executives will advise you of the reasons and what is now required. Sometimes we need further information, which is needed to properly determine whether your application meets requirements of the legislation/bank. Once confirmed, you must print and sign the Application form and send it by post along with other required documentation.
                                                    </p>
                                                    <p><strong>Step 5.</strong>
                                                        As soon as your bank account opening order is accepted and processed by the bank, you will receive your bank account details and contact details of your assigned bank official via e-mail. The password, user ID, digipass, credit/debit card and other devices will be forwarded to you by the bank direct or with assistance of Agent Legal.
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- - End13 --->
                                        <!-- - Start14 --->
                                        <div class="panel panel-default">
                                            <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                                 data-parent="#3accordion" data-target="#collapse-33"
                                                 aria-expanded="false">
                                                <h4 class="panel-title">
                                                    How long does it take to set up a bank account? </h4></div>
                                            <div class="panel-collapse collapse" id="collapse-33" aria-expanded="false">
                                                <div class="panel-body">
                                                    <p>
                                                        We begin processing your order as soon as the online purchase is completed. Processing times vary depending on the bank requirements and jurisdiction chosen. Usually the bank account can be activated within 1 week upon receipt by the bank of all required documentation and information. You will be notified via email on the progress of your account opening.</p>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- - End14 --->
                                        <!-- - Start15 --->
                                        <div class="panel panel-default">
                                            <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                                 data-parent="#3accordion" data-target="#collapse-34"
                                                 aria-expanded="false">
                                                <h4 class="panel-title">
                                                    Do I need to visit the bank personally to open an account? </h4>
                                            </div>
                                            <div class="panel-collapse collapse" id="collapse-34" aria-expanded="false">
                                                <div class="panel-body">
                                                    <p>
                                                        Most of the international banks we cooperate with do not require a personal visit and the account opening procedure may be completed remotely.</p>
                                                    <p>
                                                        If a personal interview is required, we will arrange your meeting with the bank officer in the nearest branch or representative office.</p>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- - End15 --->
                                        <!-- - Start16 --->
                                        <div class="panel panel-default">
                                            <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                                 data-parent="#3accordion" data-target="#collapse-35"
                                                 aria-expanded="false">
                                                <h4 class="panel-title">
                                                    Will the bank account be opened automatically for my new company? </h4>
                                            </div>
                                            <div class="panel-collapse collapse" id="collapse-35" aria-expanded="false">
                                                <div class="panel-body">
                                                    <p>
                                                        No. If you choose the bank account opening option, we shall review your application along with personal documentation to see if it is complete and valid. The bank will then approve or decline the account, depending on how the nature of your business and other information provided by you fits with their business model. More than 90% of our cases have been approved by the bank.</p>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- - End16 --->
                                        <!-- - Start17 --->
                                        <div class="panel panel-default">
                                            <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                                 data-parent="#3accordion" data-target="#collapse-36"
                                                 aria-expanded="false">
                                                <h4 class="panel-title">
                                                    What does Bank’s pre-approval actually mean? </h4></div>
                                            <div class="panel-collapse collapse" id="collapse-36" aria-expanded="false">
                                                <div class="panel-body">
                                                    <p>
                                                        When we receive a pre-approval confirmation from the bank regarding account opening, this means that the bank has collected all required initial information and standard set of documents on a person or company. Based on this collected information, the client qualifies for the bank account opening. If the bankers have any further questions to complete the processing of your requested account, they will <a
                                                            href="http://dev.mishatechnologies.com/contact_us">contact us</a>
                                                        for more details. Once the account is processed, approved and activated, you will have full access and will be able to send and receive payments.
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- - End17 --->
                                        <!-- - Start18 --->
                                        <div class="panel panel-default">
                                            <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                                 data-parent="#3accordion" data-target="#collapse-38"
                                                 aria-expanded="false">
                                                <h4 class="panel-title">
                                                    What happens if the bank refuses to open an account?  </h4></div>
                                            <div class="panel-collapse collapse" id="collapse-38" aria-expanded="false">
                                                <div class="panel-body">
                                                    <p>
                                                        Banks are entitled at their sole discretion to accept or reject applications to open an account, as such we will introduce you to the bank and guide through all account opening process, however we cannot guarantee that your account will be approved by the bank and successfully opened.</p>
                                                    <p>
                                                        If the bank declines your personal or corporate account, we will evaluate the situation and offer alternate banking options. However, more than 90% of our cases have been approved by the bank.</p>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- - End18 --->
                                        <!-- - Start19 --->
                                        <div class="panel panel-default">
                                            <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                                 data-parent="#3accordion" data-target="#collapse-39"
                                                 aria-expanded="false">
                                                <h4 class="panel-title">
                                                    Can Agent Legal help me choose the bank and jurisdiction? </h4>
                                            </div>
                                            <div class="panel-collapse collapse" id="collapse-39" aria-expanded="false">
                                                <div class="panel-body">
                                                    <p>
                                                        Our Corporate Executives can provide you with guidance on the bank requirements and products. However, we cannot advise you whether a bank is the best vehicle for your business. If you have any questions or need additional information, please contact our Live Chat Support or <a
                                                            href="mailto:support@agentlegal.com">send us an e-mail.</a>
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- - End19 --->
                                        <!-- - Start20 --->
                                        <div class="panel panel-default">
                                            <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                                 data-parent="#3accordion" data-target="#collapse-40"
                                                 aria-expanded="false">
                                                <h4 class="panel-title">
                                                    What information do I need to supply for my corporate account opening? </h4>
                                            </div>
                                            <div class="panel-collapse collapse" id="collapse-40" aria-expanded="false">
                                                <div class="panel-body">
                                                    <p>
                                                        Please provide the following documents for all Directors, Shareholders, Beneficial Owners, Authorized Signatories:</p>
                                                    <ul style="padding-left: 20px;">
                                                        <li><strong>Notarized copy of valid passport.</strong>
                                                            The passport must be signed and signature must match the signature in the application form. The photograph must be clear and of good quality.
                                                        </li>
                                                        <li><strong>Original or Certified copy of utility bill / bank statement</strong>
                                                            (as verification of residential address, dated within 3 months); the household utility bill (e.g. gas, electricity, water or fixed line telephone <strong>but not a mobile phone bill</strong>) or bank, building society or credit card statement as proof of address. It must be no more than 3 months old and show your name and current address. P.O. Box is not accepted.
                                                        </li>
                                                        <li><strong>Original or certified copy of Banker’s reference letter</strong>
                                                            (dated within 3 months). You can request the Reference Letter from the bank where you hold an account. The reference letter should include confirmation that the relationship has been maintain for longer than 2 years and the business affairs are run satisfactorily.
                                                        </li>
                                                        <li><strong>In cases where shareholders and/or directors are corporate bodies, full apostilled set of corporate documents will be required:</strong>
                                                            Certificate of Incorporation, List of Directors, Shareholders, Secretary, Share Certificate, copy of ‘Declaration of Trust’ between nominee shareholder(s) and ultimate beneficial owner(s) (if applicable), Certificate of Good Standing (if the company has been operating for 12 months or more); Notarized copy of a valid passport, utility bill and the reference letter for each individual Director, Shareholder and Beneficial Owner.
                                                        </li>
                                                        <li><strong>Personal CV.</strong>
                                                            In this document you should mention your work experience, qualifications, education, current place of work and position.
                                                        </li>
                                                        <li><strong>Completed and Sign Application form. </strong>The relevant Application Form you can find in ‘My Transactions’ of your account profile.
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- - End20 --->
                                        <!-- - Start21 --->
                                        <div class="panel panel-default">
                                            <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                                 data-parent="#3accordion" data-target="#collapse-41"
                                                 aria-expanded="false">
                                                <h4 class="panel-title">
                                                    What information do I need to supply for my personal account opening? </h4>
                                            </div>
                                            <div class="panel-collapse collapse" id="collapse-42" aria-expanded="false">
                                                <div class="panel-body">
                                                    <p>
                                                        Please provide the following documents for all Authorized Signatories:</p>
                                                    <ul>
                                                        <li><strong>Notarized copy of valid passport. </strong>The passport must be signed and signature must match the signature in the application form. The photograph must be clear and of good quality.
                                                        </li>
                                                        <li><strong>Original or Certified copy of utility bill / bank statement </strong>(as verification of residential address, dated within 3 months); the household utility bill (e.g. gas, electricity, water or fixed line telephone <strong>but not a mobile phone bill</strong>) or bank, building society or credit card statement as proof of address. It must be no more than 3 months old and show your name and current address. P.O. Box is not accepted.
                                                        </li>
                                                        <li><strong>Original or certified copy of Banker’s reference letter </strong>(dated within 3 months). You can request the Reference Letter from the bank where you hold an account. The reference letter should include confirmation that the relationship has been maintain for longer than 2 years and the business affairs are run satisfactorily.
                                                        </li>
                                                        <li><strong>Personal CV.</strong>
                                                            In this document you should mention your work experience, qualifications, education, current place of work and position.
                                                        </li>
                                                        <li><strong>Completed and Sign Application form.</strong>
                                                            The relevant Application Form you can find in ‘My Transactions’ of your account profile.
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- - End21 --->
                                        <!-- - Start22 --->
                                        <div class="panel panel-default">
                                            <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                                 data-parent="#3accordion" data-target="#collapse-43"
                                                 aria-expanded="false">
                                                <h4 class="panel-title">What is an EU Savings Tax Directive?</h4></div>
                                            <div class="panel-collapse collapse" id="collapse-43" aria-expanded="false">
                                                <div class="panel-body">
                                                    <p>
                                                        The European Union Savings Tax Directive (EUSTD) became effective on 1 July 2005 and applies to EU countries on interest received on savings instruments, deposit accounts, etc. Currently, it does not affect interest paid to companies. EUSTD is an agreement between the EU Member States to automatically exchange information between states about individuals who reside in one EU Member state but earn interest in another.</p>
                                                    <p>
                                                        EUSTD applies to EU residents that receive interest on savings instruments, deposit accounts, etc. Currently, it does not affect interest paid to companies.</p>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- - End22 --->
                                        <!-- - Start23 --->
                                        <div class="panel panel-default">
                                            <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                                 data-parent="#3accordion" data-target="#collapse-44"
                                                 aria-expanded="false">
                                                <h4 class="panel-title">
                                                    Who can have an access to my personal or corporate account?</h4>
                                            </div>
                                            <div class="panel-collapse collapse" id="collapse-44" aria-expanded="false">
                                                <div class="panel-body">
                                                    <p>
                                                        For security reasons we do not manage client accounts and do not offer such service. Once your account is finalized, the bank will forward all e-banking security devices, credit/debit cards and PINs directly to your correspondent address. Only authorized signatories will be able to access your personal or corporate account.</p>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- - End23 --->
                                        <!-- - Start24 --->
                                        <div class="panel panel-default">
                                            <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                                 data-parent="#3accordion" data-target="#collapse-45"
                                                 aria-expanded="false">
                                                <h4 class="panel-title">What is a Digipass (Security Token)?</h4></div>
                                            <div class="panel-collapse collapse" id="collapse-45" aria-expanded="false">
                                                <div class="panel-body">
                                                    <p>
                                                        A Digipass or a Security Token is a small device that generates a unique code. It is used together with your User ID and passcode for making payments for the high level of security of Online Banking. If you are an authorized signatory and applied for online banking, then the bank will automatically send you one of these devices.</p>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- - End24 --->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="panel panel-default">
                        <div class="panel-heading accordion-toggle icon-hide collapsed" data-toggle="collapse"
                             data-parent="#accordion-20" data-target="#collapse-11" aria-expanded="false">
                            <h4 class="panel-title">Business Activities</h4></div>
                        <div class="panel-collapse collapse" id="collapse-11" aria-expanded="false">
                            <div class="panel-body">
                                <div>
                                    <div class="panel-group" id="5accordion">
                                        <!-- - Start25 --->
                                        <div class="panel panel-default">
                                            <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                                 data-parent="#5accordion" data-target="#collapse-46"
                                                 aria-expanded="false">
                                                <h4 class="panel-title">How is my order processed?</h4></div>
                                            <div class="panel-collapse collapse" id="collapse-46" aria-expanded="false">
                                                <div class="panel-body">
                                                    <p><strong>Step 1.</strong>
                                                        Complete the online application form on the Trademark Page in four simple steps:
                                                    </p>
                                                    <ul style="padding-left: 20px;">
                                                        <li> Choose your Word Mark and/or Logo</li>
                                                        <li> Select the territory you wish to register your trademark
                                                        </li>
                                                        <li> Select the Class of your business</li>
                                                        <li>
                                                            Fill out your details in the ‘Owner’s Details’ section proceed to checkout.
                                                        </li>
                                                    </ul>
                                                    <p><strong>Step 2.</strong>
                                                        Once we receive your payment, Agent Legal will send you an email acknowledging the details of your order. We will then start to process your order further.
                                                    </p>
                                                    <p><strong>Step 3.</strong>
                                                        Your Application Form along will be reviewed no later than 1 working day after receipt. If your Application is incomplete or invalid, our Corporate Executive will advise you of the reasons and what is now required.
                                                    </p>
                                                    <p><strong>Step 4.</strong>
                                                        Once your order is accepted and processed by the Trademark Authority, you will receive your Trademark Certificate via e-mail first and then the hard copy will be couriered to your designated address.
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- - End25 --->
                                        <!-- - Start26 --->
                                        <div class="panel panel-default">
                                            <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                                 data-parent="#5accordion" data-target="#collapse-47"
                                                 aria-expanded="false">
                                                <h4 class="panel-title">What happens if my brand is not available?</h4>
                                            </div>
                                            <div class="panel-collapse collapse" id="collapse-47" aria-expanded="false">
                                                <div class="panel-body">
                                                    <p>
                                                        We will make propositions and offer solutions for changing the trademark scope in order to maximise your chances of succeeding with your application.</p>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- - End26 --->
                                        <!-- - Start27 --->
                                        <div class="panel panel-default">
                                            <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                                 data-parent="#5accordion" data-target="#collapse-48"
                                                 aria-expanded="false">
                                                <h4 class="panel-title">What is a Community trademark (CTM)?</h4></div>
                                            <div class="panel-collapse collapse" id="collapse-48" aria-expanded="false">
                                                <div class="panel-body">
                                                    <p>
                                                        The CTM is a unified trademark registered in the European Union and grants an exclusive right in all member states of the EU. The CTM system is administered by the Office for Harmonization in the Internal Market (Trade Marks and Designs) (OHIM).</p>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- - End27 --->
                                        <!-- - Start28 --->
                                        <div class="panel panel-default">
                                            <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                                 data-parent="#5accordion" data-target="#collapse-49"
                                                 aria-expanded="false">
                                                <h4 class="panel-title">
                                                    Can you register trademarks in non-EU countries?</h4></div>
                                            <div class="panel-collapse collapse" id="collapse-49" aria-expanded="false">
                                                <div class="panel-body">
                                                    <p>
                                                        Yes, we can assist with trademark registration in all member countries of the Madrid treaties and other non-member countries. If you wish to register your trademark outside of EU, please send us your request via our <a
                                                            href="http://dev.mishatechnologies.com/creditkazzamblog/index.php?module=contact_us">Contact Form</a>.
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- - End28 --->
                                        <!-- - Start29 --->
                                        <div class="panel panel-default">
                                            <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                                 data-parent="#5accordion" data-target="#collapse-50"
                                                 aria-expanded="false">
                                                <h4 class="panel-title">Who can file a trademark application?</h4></div>
                                            <div class="panel-collapse collapse" id="collapse-50" aria-expanded="false">
                                                <div class="panel-body">
                                                    <p>
                                                        An application for a registered trademark can be filed by any individual, company or legal entity for use of representing goods or services in the market. Many people seek the assistance of a professional consultancy firm to facilitate the trademark search and registration application on their behalf as the process can be time consuming and complex depending on the jurisdictions you seek to register in.</p>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- - End29 --->
                                        <!-- - Start30 --->
                                        <div class="panel panel-default">
                                            <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                                 data-parent="#5accordion" data-target="#collapse-51"
                                                 aria-expanded="false">
                                                <h4 class="panel-title">
                                                    What are the main benefits of registering a trademark?</h4></div>
                                            <div class="panel-collapse collapse" id="collapse-51" aria-expanded="false">
                                                <div class="panel-body">
                                                    <p>
                                                        Registering a trademark will ensure that your business entities name, identity and logo are protected and it grants you exclusive ownership in your selected jurisdiction/s of registration. It also ensures that your entities brand, name or logo does not infringe other registered trademarks while granting you legal rights; and if need be, allowing you the ability to take legal action against any party that infringes your trademark rights. A registered trademark will instantly make competitors aware that the trademark is already taken and deter them from using a trademark that is similar.</p>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- - End30 --->
                                        <!-- - Start31 --->
                                        <div class="panel panel-default">
                                            <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                                 data-parent="#5accordion" data-target="#collapse-52"
                                                 aria-expanded="false">
                                                <h4 class="panel-title">What can I register as a trade mark?</h4></div>
                                            <div class="panel-collapse collapse" id="collapse-52" aria-expanded="false">
                                                <div class="panel-body">
                                                    <p>
                                                        Any available name, slogan, logo, colour, smell, strap-line, buy-line, design, shape, etc. can be registered as a trademark.</p>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- - End31 --->
                                        <!-- - Start32 --->
                                        <div class="panel panel-default">
                                            <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                                 data-parent="#5accordion" data-target="#collapse-53"
                                                 aria-expanded="false">
                                                <h4 class="panel-title">How long does a trademark last?</h4></div>
                                            <div class="panel-collapse collapse" id="collapse-53" aria-expanded="false">
                                                <div class="panel-body">
                                                    <p>
                                                        The validity of a registered trademark depends on the jurisdiction/s the mark is registered in. Typically, most jurisdictions adopt a validity period of 10 consecutive years from the date of registration. A registered trademark is also renewable every 10 years thereafter provided the mark was used in compliance with the appropriate trademark laws. Some jurisdictions stipulate that non use of a trademark for a specified period of time will result in removal and revocation of trademark rights from the owner.</p>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- - End32 --->
                                        <!-- - Start33 --->
                                        <div class="panel panel-default">
                                            <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                                 data-parent="#5accordion" data-target="#collapse-54"
                                                 aria-expanded="false">
                                                <h4 class="panel-title">
                                                    How long will a trade-mark application take to process?</h4></div>
                                            <div class="panel-collapse collapse" id="collapse-54" aria-expanded="false">
                                                <div class="panel-body">
                                                    <p>About 9 to 12 months depending on various factors.</p>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- - End33 --->
                                        <!-- - Start34 --->
                                        <div class="panel panel-default">
                                            <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                                 data-parent="#5accordion" data-target="#collapse-55"
                                                 aria-expanded="false">
                                                <h4 class="panel-title">
                                                    What is the difference between the notations TM, SM and ®?</h4>
                                            </div>
                                            <div class="panel-collapse collapse" id="collapse-55" aria-expanded="false">
                                                <div class="panel-body">
                                                    <p>
                                                        The symbol TM adopted on an unregistered trademark while the symbol ® is used to demonstrate a registered trademark. In addition to trademarks are service marks denoted by the symbol SM.</p>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- - End34 --->
                                        <!-- - Start35 --->
                                        <div class="panel panel-default">
                                            <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                                 data-parent="#5accordion" data-target="#collapse-56"
                                                 aria-expanded="false">
                                                <h4 class="panel-title">
                                                    How often does my trademark need to be renewed?</h4></div>
                                            <div class="panel-collapse collapse" id="collapse-56" aria-expanded="false">
                                                <div class="panel-body">
                                                    <p>
                                                        The renewal of a registered trademark will typically take place every 10 years as this is the most commonly used validity period of a trademark. The trademark owner will be notified up to 6 months prior to expiry of the trademark and then trademark renewal proceedings will be put into place, either by the owner or by a representative professional consultant. A registered trademark needs to be renewed for as long as it is required in commerce, as non-renewal will render the trademark redundant and without any legal protection.</p>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- - End35 --->
                                        <!-- - Start36 --->
                                        <div class="panel panel-default">
                                            <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                                 data-parent="#5accordion" data-target="#collapse-57"
                                                 aria-expanded="false">
                                                <h4 class="panel-title">
                                                    Do I have the right to sue where I believe my trademark rights are infringed?</h4>
                                            </div>
                                            <div class="panel-collapse collapse" id="collapse-57" aria-expanded="false">
                                                <div class="panel-body">
                                                    <p>
                                                        The first thing to note is that the infringing trademark must have caused a “likelihood of confusion” to the public and it must have caused harm to your registered trademark. The main factors taken into account for cases of trademark infringement are the similarity of the trademarks in question and the similar of the goods/services the marks represent. Under trademark law, all owners of a registered trademark have exclusive rights and are provided with a great deal of legal protection in cases of infringement or passing off.</p>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- - End36 --->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="panel panel-default">
                        <div class="panel-heading accordion-toggle icon-hide collapsed" data-toggle="collapse"
                             data-parent="#accordion-20" data-target="#collapse-12" aria-expanded="false">
                            <h4 class="panel-title">Trademark Registration FAQs</h4></div>
                        <div class="panel-collapse collapse" id="collapse-12" aria-expanded="false"
                             style="height: 0px;">
                            <div class="panel-body">
                                <div>
                                    <div class="panel-group" id="6accordion">
                                        <!-- - Start25 --->
                                        <div class="panel panel-default">
                                            <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                                 data-parent="#6accordion" data-target="#collapse-58"
                                                 aria-expanded="false">
                                                <h4 class="panel-title">How is my order processed?</h4></div>
                                            <div class="panel-collapse collapse" id="collapse-58" aria-expanded="false">
                                                <div class="panel-body">
                                                    <p><strong>Step 1.</strong>
                                                        Complete the online application form on the Trademark Page in four simple steps:
                                                    </p>
                                                    <ul style="padding-left: 20px;">
                                                        <li> Choose your Word Mark and/or Logo</li>
                                                        <li> Select the territory you wish to register your trademark
                                                        </li>
                                                        <li> Select the Class of your business</li>
                                                        <li>
                                                            Fill out your details in the ‘Owner’s Details’ section proceed to checkout.
                                                        </li>
                                                    </ul>
                                                    <p><strong>Step 2.</strong>
                                                        Once we receive your payment, Agent Legal will send you an email acknowledging the details of your order. We will then start to process your order further.
                                                    </p>
                                                    <p><strong>Step 3.</strong>
                                                        Your Application Form along will be reviewed no later than 1 working day after receipt. If your Application is incomplete or invalid, our Corporate Executive will advise you of the reasons and what is now required.
                                                    </p>
                                                    <p><strong>Step 4.</strong>
                                                        Once your order is accepted and processed by the Trademark Authority, you will receive your Trademark Certificate via e-mail first and then the hard copy will be couriered to your designated address.
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- - End25 --->
                                        <!-- - Start26 --->
                                        <div class="panel panel-default">
                                            <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                                 data-parent="#6accordion" data-target="#collapse-59"
                                                 aria-expanded="false">
                                                <h4 class="panel-title">What happens if my brand is not available?</h4>
                                            </div>
                                            <div class="panel-collapse collapse" id="collapse-59" aria-expanded="false">
                                                <div class="panel-body">
                                                    <p>
                                                        We will make propositions and offer solutions for changing the trademark scope in order to maximise your chances of succeeding with your application.</p>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- - End26 --->
                                        <!-- - Start27 --->
                                        <div class="panel panel-default">
                                            <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                                 data-parent="#6accordion" data-target="#collapse-60"
                                                 aria-expanded="false">
                                                <h4 class="panel-title">What is a Community trademark (CTM)?</h4></div>
                                            <div class="panel-collapse collapse" id="collapse-60" aria-expanded="false">
                                                <div class="panel-body">
                                                    <p>
                                                        The CTM is a unified trademark registered in the European Union and grants an exclusive right in all member states of the EU. The CTM system is administered by the Office for Harmonization in the Internal Market (Trade Marks and Designs) (OHIM).</p>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- - End27 --->
                                        <!-- - Start28 --->
                                        <div class="panel panel-default">
                                            <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                                 data-parent="#6accordion" data-target="#collapse-61"
                                                 aria-expanded="false">
                                                <h4 class="panel-title">
                                                    Can you register trademarks in non-EU countries?</h4></div>
                                            <div class="panel-collapse collapse" id="collapse-61" aria-expanded="false">
                                                <div class="panel-body">
                                                    <p>
                                                        Yes, we can assist with trademark registration in all member countries of the Madrid treaties and other non-member countries. If you wish to register your trademark outside of EU, please send us your request via our <a
                                                            href="http://dev.mishatechnologies.com/creditkazzamblog/index.php?module=contact_us">Contact Form</a>.
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- - End28 --->
                                        <!-- - Start29 --->
                                        <div class="panel panel-default">
                                            <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                                 data-parent="#6accordion" data-target="#collapse-62"
                                                 aria-expanded="false">
                                                <h4 class="panel-title">Who can file a trademark application?</h4></div>
                                            <div class="panel-collapse collapse" id="collapse-62" aria-expanded="false">
                                                <div class="panel-body">
                                                    <p>
                                                        An application for a registered trademark can be filed by any individual, company or legal entity for use of representing goods or services in the market. Many people seek the assistance of a professional consultancy firm to facilitate the trademark search and registration application on their behalf as the process can be time consuming and complex depending on the jurisdictions you seek to register in.</p>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- - End29 --->
                                        <!-- - Start30 --->
                                        <div class="panel panel-default">
                                            <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                                 data-parent="#6accordion" data-target="#collapse-63"
                                                 aria-expanded="false">
                                                <h4 class="panel-title">
                                                    What are the main benefits of registering a trademark?</h4></div>
                                            <div class="panel-collapse collapse" id="collapse-63" aria-expanded="false">
                                                <div class="panel-body">
                                                    <p>
                                                        Registering a trademark will ensure that your business entities name, identity and logo are protected and it grants you exclusive ownership in your selected jurisdiction/s of registration. It also ensures that your entities brand, name or logo does not infringe other registered trademarks while granting you legal rights; and if need be, allowing you the ability to take legal action against any party that infringes your trademark rights. A registered trademark will instantly make competitors aware that the trademark is already taken and deter them from using a trademark that is similar.</p>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- - End30 --->
                                        <!-- - Start31 --->
                                        <div class="panel panel-default">
                                            <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                                 data-parent="#6accordion" data-target="#collapse-64"
                                                 aria-expanded="false">
                                                <h4 class="panel-title">What can I register as a trade mark?</h4></div>
                                            <div class="panel-collapse collapse" id="collapse-64" aria-expanded="false">
                                                <div class="panel-body">
                                                    <p>
                                                        Any available name, slogan, logo, colour, smell, strap-line, buy-line, design, shape, etc. can be registered as a trademark.</p>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- - End31 --->
                                        <!-- - Start32 --->
                                        <div class="panel panel-default">
                                            <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                                 data-parent="#6accordion" data-target="#collapse-65"
                                                 aria-expanded="false">
                                                <h4 class="panel-title">How long does a trademark last?</h4></div>
                                            <div class="panel-collapse collapse" id="collapse-65" aria-expanded="false">
                                                <div class="panel-body">
                                                    <p>
                                                        The validity of a registered trademark depends on the jurisdiction/s the mark is registered in. Typically, most jurisdictions adopt a validity period of 10 consecutive years from the date of registration. A registered trademark is also renewable every 10 years thereafter provided the mark was used in compliance with the appropriate trademark laws. Some jurisdictions stipulate that non use of a trademark for a specified period of time will result in removal and revocation of trademark rights from the owner.</p>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- - End32 --->
                                        <!-- - Start33 --->
                                        <div class="panel panel-default">
                                            <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                                 data-parent="#6accordion" data-target="#collapse-66"
                                                 aria-expanded="false">
                                                <h4 class="panel-title">
                                                    How long will a trade-mark application take to process?</h4></div>
                                            <div class="panel-collapse collapse" id="collapse-66" aria-expanded="false">
                                                <div class="panel-body">
                                                    <p>About 9 to 12 months depending on various factors.</p>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- - End33 --->
                                        <!-- - Start34 --->
                                        <div class="panel panel-default">
                                            <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                                 data-parent="#6accordion" data-target="#collapse-67"
                                                 aria-expanded="false">
                                                <h4 class="panel-title">
                                                    What is the difference between the notations TM, SM and ®?</h4>
                                            </div>
                                            <div class="panel-collapse collapse" id="collapse-67" aria-expanded="false">
                                                <div class="panel-body">
                                                    <p>
                                                        The symbol TM adopted on an unregistered trademark while the symbol ® is used to demonstrate a registered trademark. In addition to trademarks are service marks denoted by the symbol SM.</p>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- - End34 --->
                                        <!-- - Start35 --->
                                        <div class="panel panel-default">
                                            <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                                 data-parent="#6accordion" data-target="#collapse-68"
                                                 aria-expanded="false">
                                                <h4 class="panel-title">
                                                    How often does my trademark need to be renewed?</h4></div>
                                            <div class="panel-collapse collapse" id="collapse-68" aria-expanded="false">
                                                <div class="panel-body">
                                                    <p>
                                                        The renewal of a registered trademark will typically take place every 10 years as this is the most commonly used validity period of a trademark. The trademark owner will be notified up to 6 months prior to expiry of the trademark and then trademark renewal proceedings will be put into place, either by the owner or by a representative professional consultant. A registered trademark needs to be renewed for as long as it is required in commerce, as non-renewal will render the trademark redundant and without any legal protection.</p>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- - End35 --->
                                        <!-- - Start36 --->
                                        <div class="panel panel-default">
                                            <div class="panel-heading accordion-toggle collapsed" data-toggle="collapse"
                                                 data-parent="#5accordion" data-target="#collapse-69"
                                                 aria-expanded="false">
                                                <h4 class="panel-title">
                                                    Do I have the right to sue where I believe my trademark rights are infringed?</h4>
                                            </div>
                                            <div class="panel-collapse collapse" id="collapse-69" aria-expanded="false">
                                                <div class="panel-body">
                                                    <p>
                                                        The first thing to note is that the infringing trademark must have caused a “likelihood of confusion” to the public and it must have caused harm to your registered trademark. The main factors taken into account for cases of trademark infringement are the similarity of the trademarks in question and the similar of the goods/services the marks represent. Under trademark law, all owners of a registered trademark have exclusive rights and are provided with a great deal of legal protection in cases of infringement or passing off.</p>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- - End36 --->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- -->
            </div>
        </section>
        <section class="contact_us_faq">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12">
                        <div class="contact-faq">
                            <h3>Didn't find what you were looking for ?</h3>
                            <div class="button">
                                <a href="/#/contact">
                                    <button class="btn btn-green">Contact Us</button>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>
</template>
