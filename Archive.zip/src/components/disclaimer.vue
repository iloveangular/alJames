<template>
    <main>
        <section class="privacy-policy">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="title">
                            <h2><span>Disclaimer</span></h2>
                            <hr>
                            <p>The Agent Legal websites are provided on an "AS IS" and "AS AVAILABLE" basis without any representation or endorsement made and without warranty of any kind whether express or implied, including but not limited to the implied warranties of satisfactory quality, fitness for a particular purpose, non-infringement, compatibility, security and accuracy.</p>
                            <p>Any and all liability to you that may arise from your access to and use of the websites, whether due to negligence, breach of duty or otherwise, is excluded to the maximum extent permitted by law.</p>
                            <p>The content of Agent Legal websites is for general information only and does not constitute legal or other professional advice. Every reasonable care has been taken to ensure that the information given on our sites is accurate and up-to-date, and we cannot accept responsibility for any consequences whatsoever arising out of reliance upon or usage of such general information as aforesaid. Your use of any of our sites does not create attorney/consultant/advisor – client relationship with Agent Legal, nor does such use constitute the receipt of legal or other professional advice from Agent Legal. All users of our sites, whether or not the users are existing clients of Agent Legal, are advised to <a href="/contact">Contact us</a> and/or to take appropriate professional advice before committing themselves to any act or taking any decision regarding services requested.</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>
</template>