<template>

</template>
<script>
  export default {
    data() {
      return {
          someMsg: 'Hello there',
      }
    }
  }
</script>
