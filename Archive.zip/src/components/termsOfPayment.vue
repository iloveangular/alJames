<template>
    <main>
        <section class="packages first privacy_policy">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="title">
                            <h2><span>Terms of Payment</span></h2>
                            <br>
                            <div id="terms">
                                <p>These Terms of Payment must be read together with the <a href="/terms"
                                                                                            title="Terms and Conditions of Business">Terms and Conditions of Business</a>. The <a
                                        href="/terms" title="Terms and Conditions of Business">Terms and Conditions of Business</a>
                                    apply to any agreement between Agent Legal and the Client generally, including for the avoidance of doubt the jurisdiction and governing law clause.
                                </p>
                                <ol class="terms">
                                    <li class="bold">PAYMENT COLLECTIONS AND FEES</li>
                                    <ol>
                                        <li>
                                            All credit and debit card payments for Agent Legal products and services are collected by DELTAQUEST Media (Ireland) Ltd, Company No IE548227, Registered address: The Black Church, The Black Church,St. Mary's Place, Dublin 7, Ireland. DELTAQUEST Media (Ireland) Ltd is a wholly owned subsidiary of Agent Legal Pte. Ltd.
                                        </li>
                                        <li>
                                            Fees shall be payable as per invoices issued by Agent Legal to the Client. Should the Client fails to settle any invoice within a period as shall be specified in the invoice, Agent Legal reserve the right not to provide any service and/or to discontinue the provision of services, and shall not be responsible for any costs, fees, duties or taxes owed by the Client to any agent and/or government authority in any jurisdiction, any fines or fees incurred by the Client as a result of such withdrawal of services, nor for any consequential loss or claim made against the Client by any third party arising due to the non-payment. Should the Client maintains credit balance with Agent Legal and fails to settle any invoice within specified deadline, Agent Legal shall have the right to withdraw the respective due amount from such credit balance without Client's prior consent.
                                        </li>
                                        <li>
                                            Fees for services and products offered by Agent Legal are published from time to time on the Agent Legal's web sites, or may be notified to, or agreed with the Clients through direct communication. Agent Legal reserves the right to, if in our reasonable opinion, the economic conditions so necessitate, increase the fees without obligation to inform, or seek prior approval from, the Client.
                                        </li>
                                        <li>
                                            Fees shall be payable as per invoices issued by Agent Legal to the Client. Should the Client fails to settle any invoice within a period as shall be specified in the invoice, Agent Legal reserve the right not to provide any service and/or to discontinue the provision of services, and shall not be responsible for any costs, fees, duties or taxes owed by the Client to any agent and/or government authority in any jurisdiction, any fines or fees incurred by the Client as a result of such withdrawal of services, nor for any consequential loss or claim made against the Client by any third party arising due to the non-payment. Should the Client maintains credit balance with Agent Legal and fails to settle any invoice within specified deadline, Agent Legal shall have the right to withdraw the respective due amount from such credit balance without Client's prior consent.
                                        </li>
                                        <li>
                                            The price for any goods or services excludes GST (Goods and Services Tax), unless specified otherwise. The total purchase price, including GST, if any, will be displayed in the Client's shopping cart prior to the payment for the order.
                                        </li>
                                        <li>
                                            Agent Legal's fees for providing the Services will be based on the fee schedule in force at the time when the work is being performed. Agent Legal reserve the right periodically to update the prices on Agent Legal's web sites and to add to, amend, or withdraw the products and services that are offered, without prior notice. Agent Legal shall not be liable to anyone for withdrawing or amending any of the products we sell, or for refusing or failing to process an order.
                                        </li>
                                        <li>
                                            Agent Legal will not pay any interest on any money held on behalf of the Client or the Entity.
                                        </li>
                                    </ol>
                                    <li class="bold">REFUNDS AND CANCELLATIONS</li>
                                    <ol>
                                        <li>
                                            No refunds are given after Client's order has been executed by Agent Legal partially or in full. No refunds will be made where Agent Legal is forced to refuse and/or cease to provide Services due to any breach by the Client of the warranties, obligations and undertakings as specified in clauses 7-10 of this Terms and Conditions.
                                        </li>
                                        <li>
                                            Should Client purchases any of the services online via any of the Agent Legal's web sites and decides to cancel the order before Agent Legal start to execute such order, Agent Legal will refund all monies paid by the Client, except for an administration charge of US$ 200, which include merchant charges, order processing fees and other incidental expenses. The refund can be claimed within 180 days from the day of the payment. No refunds shall be given for the claims exceeding 180 days.
                                        </li>
                                        <li>
                                            Should Agent Legal cease to provide Services or should the Client advise Agent Legal that they no longer require the Entity, the Client must pay Agent Legal any already incurred fees, which remain outstanding and fees or costs, which may be incurred by Agent Legal in relation to the striking off, dissolution, liquidation or transfer of the Entity, including Agent Legal's transfer, termination or exit fee.
                                        </li>
                                        <li>
                                            In the case of transfer of administration of the Entity to another service provider, Agent Legal will charge, and the Client will be obliged to pay, a transfer, or termination, or exit fee, or company release fee in accordance with the fee schedule valid on the date of the transfer, along with all outstanding fees incurred and being owed by the Client to Agent Legal up to the date of such transfer.
                                        </li>
                                    </ol>
                                </ol>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>
</template>