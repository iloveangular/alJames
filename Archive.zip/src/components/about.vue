<template>
    <main class="about-us">
        <section class="banner">
            <div class="banner_content">
                <img src="src/assets/images/logo.png" class="logo">
                <h3>Our goal is to provide the ultimate business start-up platform, to help businesses
                    <strong>get up and running with all the tools at hand.</strong></h3>
            </div>
        </section>
        <!-- -->
        <!-- about-area-->
        <section class="about">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12">
                        <div class="about_main">
                            <h2>About the Agent Legal Store</h2>
                            <hr>
                            <p><b>Agent Legal</b>
                                is much more than a traditional corporate services provider. What makes us unique? It is the fact that we form close partnerships with our clients to help guide them on the best business solutions to suit their needs. This
                                way, we get to know our clients’ individual needs in a way that the average consultancy does not. We are committed to providing quality consultancy services across an array of industries, and it is by tailoring these services for each client
                                that we excel in being one of the most efficient and cost-effective business solutions provider in the world.
                            </p>
                            <p>
                                Our worldwide team of experts has extensive experience in the business of international corporate services and consulting. You do not need to worry about your company, market entry, bank accounts, legal compliance, accounting, taxes or recruitment.
                                We can do it all for you, quickly and efficiently.</p>
                            <p>
                                Our worldwide network covering over 60 jurisdictions is dedicated to providing you with prompt, professional advice and high-quality management services for your business.</p>
                            <p>
                                Agent Legal endeavours to provide first-class yet affordable business solutions at your fingertips.</p>
                            <p><b>WE WILL HELP YOUR BUSINESS GROW!</b></p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- -->
        <!-- service-area-->
        <section class="service_area">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12">
                        <div class="service_main about">
                            <h2>Our Products & Services</h2>
                            <hr>
                            <div class="product">
                                <div class="default">
                                    <div class="bg-red">
                                        <div class="sprite register-company"></div>
                                    </div>
                                    <h3>Company Formation</h3>
                                </div>
                                <div class="hover">
                                    <h3>Company Formation</h3>
                                    <p>Available across 5 continents, in 50+ countries</p>
                                    <p>Corporate packages to start your business right away</p>
                                    <p>Company administration and expert legal support</p>
                                    <a href="/#/companies">Learn More</a>
                                </div>
                            </div>
                            <div class="product">
                                <div class="default">
                                    <div class="bg-red">
                                        <div class="sprite bank-account"></div>
                                    </div>
                                    <h3>Bank Account Opening</h3>
                                </div>
                                <div class="hover">
                                    <h3>Bank Account Opening</h3>
                                    <p>Available across 5 continents with 40+ banks</p>
                                    <p>Assistance with international bank account opening</p>
                                    <p>Banking solutions for your personal and business needs</p>
                                    <a href="/#/banks">Learn More</a>
                                </div>
                            </div>
                            <div class="product">
                                <div class="default">
                                    <div class="bg-red">
                                        <div class="sprite register-trademark" style="top: 20px;"></div>
                                    </div>
                                    <h3>Trademark Registration</h3>
                                </div>
                                <div class="hover">
                                    <h3>Trademark Registration</h3>
                                    <p>Available across 5 continents, in 70+ countries.</p>
                                    <p>Global trademark search, registration, monitoring and maintenance.</p>
                                    <p>Brand & intellectual property expert support.</p>
                                    <a href="/#/trademarks">Learn More</a>
                                </div>
                            </div>
                            <div class="product">
                                <div class="default">
                                    <div class="bg-red">
                                        <div class="sprite special-offers"></div>
                                    </div>
                                    <h3>Business eBooks</h3>
                                </div>
                                <div class="hover">
                                    <h3>Business eBooks</h3>
                                    <p>
                                        Soon to come will be our downloadable and specialist business eBooks. Our eBooks will cover a host of business startup and management topics to help guide you to make better informed decisions.</p>
                                </div>
                            </div>
                            <div class="product">
                                <div class="default">
                                    <div class="bg-red">
                                        <div class="sprite download-docs"></div>
                                    </div>
                                    <h3>Business Documents</h3>
                                </div>
                                <div class="hover">
                                    <h3>Business Documents</h3>
                                    <p>
                                        We offer quick and affordable access to more than 1000 downloadable and ready-to-complete business forms and legal documents suited for both business and personal use.</p>
                                    <a href="/#/documents">Learn More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- -->
        <!-- tab-area-->
        <section class="tab_area">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12">
                        <div class="tab_main about">
                            <h2>Why Choose Us</h2>
                            <hr>
                            <ul class="faq panel-group" id="accordion-about">
                                <div class="margin panel">
                                    <li class="q" data-toggle="collapse" data-parent="#accordion-about" href="#about-1">
                                        <div class="sprite1 secure left"></div>
                                        <i aria-hidden="true" class="fa fa-chevron-down"></i> Secure & Trustworthy
                                    </li>
                                    <li class="a panel-collapse collapse" id="about-1">
                                        Protection of your security data and personal confidential information are of vital importance to Agent Legal. We ensure that your data is secure and that we meet the highest security standards and confidentiality principals. Your personal
                                        data will not be disclosed by us, nor will it be shared, sold or announced to any third party.
                                    </li>
                                </div>
                                <div class="margin">
                                    <li class="q" data-toggle="collapse" data-parent="#accordion-about" href="#about-2">
                                        <div class="sprite1 expert_advice left"></div>
                                        <i aria-hidden="true" class="fa fa-chevron-down"></i> Expert Advice
                                    </li>
                                    <li class="a panel-collapse collapse" id="about-2">
                                        Agent Legal is committed to the highest degree of professionalism and integrity. Our team of experienced advisors is well positioned to offer guidance regarding company formation and structuring, tax optimization, administration services
                                        and bank account opening, so you can make wise business decisions. Our Live Support allows our clients to use instant messaging to contact our team via the Agent Legal website in order to receive immediate assistance.
                                    </li>
                                </div>
                                <div class="margin">
                                    <li class="q" data-toggle="collapse" data-parent="#accordion-about" href="#about-3">
                                        <div class="sprite1 continous_support left"></div>
                                        <i aria-hidden="true" class="fa fa-chevron-down"></i>Continuous Support
                                    </li>
                                    <li class="a panel-collapse collapse" id="about-3">
                                        Once you have submitted your order we will continue to support you with any updates that arise and provide consultation to ensure that you get the highest quality service. We will monitor your case until your business package is received.
                                        Our Live Support allows you to quickly locate a customer support representative that will assist with any questions and information regarding our products and services.
                                    </li>
                                </div>
                                <div class="margin">
                                    <li class="q" data-toggle="collapse" data-parent="#accordion-about" href="#about-4">
                                        <div class="sprite1 quick_easy left"></div>
                                        <i aria-hidden="true" class="fa fa-chevron-down"></i>Quick & Easy Procedure
                                    </li>
                                    <li class="a panel-collapse collapse" id="about-4">
                                        We make the process of company formation or bank account opening as simple and quick as possible. Agent Legal provides all kinds of tools and services to get you started. Not sure what to choose? You can talk to a member of our support staff
                                        in real time with live chat. Our Customer support team will be glad to assist you.
                                    </li>
                                </div>
                                <div class="margin">
                                    <li class="q" data-toggle="collapse" data-parent="#accordion-about" href="#about-5">
                                        <div class="sprite1 competitive left"></div>
                                        <i aria-hidden="true" class="fa fa-chevron-down"></i>Competitive Pricing
                                    </li>
                                    <li class="a panel-collapse collapse" id="about-4">
                                        Our goal is to provide you with the best customer service at the best possible price. Agent Legal clearly displays pricing and there are no hidden fees. When choosing Agent Legal, you can be sure that our packages will include all that you
                                        need to establish and operate your company or open a bank account with no hidden costs. We do not try to sell products or services that you do not need.
                                    </li>
                                </div>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>
</template>
