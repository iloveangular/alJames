<template>
    <main>
        <section class="privacy-policy">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="title"><h2><span>Terms of Use</span></h2>
                            <hr>
                            <p>
                                This site is the property of Agent Legal, LLC. The term ‘Agent Legal’, ‘us’ or ‘we’ refers to the owner of this
                                website.&nbsp; The term ‘you’ refers to the user or viewer of our website.</p>
                            <p>The use of this website is subject to the following terms of use:</p>
                            <ol class="terms">
                                <li>
                                    The content of the pages of this website or other websites owned and/or operated by Agent Legal is for
                                    your general information and use only. The information, material and content provided in the pages
                                    of our sites may be changed at any time without notice. All our products and services offered by
                                    Agent Legal are subject to the separate terms and conditions, policies and disclaimers governing their
                                    use.&nbsp; This Terms of Use are to be read by you together with any terms, conditions, policies&nbsp; and
                                    disclaimers published on our&nbsp; web sites or provided by our employees upon your request, &nbsp;and they
                                    supersede any prior understanding or agreements, written or oral.
                                </li>
                                <li>
                                    Neither we, nor any third parties provide any warranty or guarantee as to the accuracy, timeliness,
                                    performance, completeness or suitability of the information and materials found or offered on our
                                    website for any particular purpose. You acknowledge that such information and materials may contain
                                    inaccuracies or errors and we expressly exclude liability for any such inaccuracies or errors to the
                                    fullest extent permitted by law.
                                </li>
                                <li>
                                    Your use of any information or materials on our websites is entirely at your own risk, for which we
                                    shall not be liable. It shall be your own responsibility to ensure that any products, services or
                                    information available through our websites meet your specific requirements and are permitted by the
                                    laws of the country of your domicile.
                                </li>
                                <li>
                                    This website contains material which is owned by or licensed to Agent Legal. Copyright in the content of
                                    each of our sites (including without limitation all images, illustrations, designs, icons,
                                    photographs,&nbsp; trademarks, service marks, the ‘look’ and ‘feel’, color combinations, button shapes,
                                    layout, design, graphical elements, arrangement of items, written and other materials, HTML and
                                    other code and all copyrightable or otherwise legally protectable elements on our sites) are legally
                                    protected under intellectual property laws. The modification, copying, distribution or incorporation
                                    into any other work of part or all of any of our sites, or the content in any form, is prohibited,
                                    except that you may print or download extracts for your non-commercial, informational and personal
                                    use only. All rights are hereby&nbsp;reserved.
                                </li>
                                <li>
                                    Unauthorized use of our websites may give rise to a claim for damages and/or be a criminal
                                    offence.
                                </li>
                                <li>
                                    From time to time our websites may also include links to other websites. These links are provided
                                    for your convenience and further information. They do not signify that we endorse or approve in any
                                    way those linked websites. We expressly disclaim any responsibility for the content of the linked
                                    websites.
                                </li>
                                <li>
                                    You may not create a link to our websites from another website or document without our prior written
                                    consent.
                                </li>
                                <li>
                                    Messages sent through our sites are considered to be messages sent over Internet and cannot be
                                    guaranteed to be completely secure as they are subject to possible interception, loss, or possible
                                    alteration. We are not responsible and will not be liable to you or anyone else for any damages or
                                    otherwise in connection with any message sent by you to us or any message sent by us to you over the
                                    Internet.
                                </li>
                                <li>
                                    You agree to defend&nbsp; us&nbsp; against all claims, demands, or actions arising from or incurred as a
                                    result of your breach of these Terms of Use and you shall indemnify and hold us harmless from and
                                    against any expenses, losses, damages and costs, including but not limited to reasonable legal costs
                                    and disbursements, resulting from any such claims.
                                </li>
                                <li>
                                    Your use of our websites and the purchase of any products or services from them are governed in
                                    accordance with the laws of Singapore. The courts of Singapore shall have exclusive jurisdiction
                                    over any dispute or difference whatsoever arising out of or in connection with your use of the web
                                    sites or the purchase of any products or services from them.
                                    If, for any reason, you are unable or unwilling to agree to all of our terms, policies or
                                    disclaimers,&nbsp;please immediately discontinue using or attempting to use of our sites, because if you
                                    continue, you will be agreeing to all the terms, conditions,&nbsp; policies and disclaimers&nbsp; referred to
                                    in this Terms of Use.
                                </li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>
</template>