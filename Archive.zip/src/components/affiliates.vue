<template>
    <main class="affiliates">
        <section class="section-1">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-lg-7 col-xs-12 visible-xs">
                        <img src="src/assets/images/starting-business-affiliates-program.png"
                             alt="Agent Legal Affiliates Program">
                    </div>
                    <div class="col-md-6 col-lg-5 col-sm-6 col-xs-12">
                        <h4>Unlimited Earning Potential</h4>
                        <h2>5% Commission</h2>
                        <h3>for all sales generated</h3><a :href="'/#/affiliates/signup'"
                                                           class="hh-btn btn-green large">Sign Up</a><br>
                        <p>Already registered? <a :href="'/#/login'" class="text-green">Login</a></p>
                    </div>
                    <div class="col-md-6 col-lg-7 col-sm-6 text-right sec-1-r hidden-xs">
                        <img src="src/assets/images/starting-business-affiliates-program.png"
                             alt="Agent Legal Affiliates Program">
                    </div>
                </div>
            </div>
        </section>
        <section class="section-2">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 col-md-12 col-sm-12">
                        <div class="col-md-6 col-lg-8 col-xs-12 pre-com">
                            <div class="commission">
                                <h4>GUARANTEED</h4>
                                <h3>5% Commission</h3>
                            </div>
                        </div>
                        <div class="col-md-6 col-lg-11 col-xs-12">
                            <h2>Monetize your Traffic</h2>
                            <p>
                                Are you a blogger, a publisher or a business professional? With the Agent Legal Affiliate Program, you are able to monetize your audience and drive leads to purchase reliable corporate services.</p>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-12 col-xs-12">
                        <div class="row">
                            <div class="col-lg-4 col-md-4 col-xs-12">
                                <div class="wrap-widget">
                                    <img src="src/assets/images/affiliate-sign-up.png" alt="Affiliate Sign Up">
                                    <p>Join the Agent Legal Affiliate Program today to get started.</p>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-4 col-xs-12">
                                <div class="wrap-widget transparent">
                                    <img src="src/assets/images/affiliate-marketing.png" alt="Affiliate Marketing">
                                    <p>Use our marketing materials to drive leads to buy our services.</p>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-4 col-xs-12">
                                <div class="wrap-widget">
                                    <img src="src/assets/images/paid-leads.png" alt="Paid Leads">
                                    <p>Get paid for every sale your leads generate - 5% guaranteed.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section class="section-3">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8 col-md-8 col-lg-offset-2 col-md-offset-2">
                        <h1>The best features of our business affiliate program</h1>
                    </div>
                    <div class="row">
                        <div class="col-xs-12 col-sm-6 col-md-6 col-lg-3">
                            <img src="src/assets/images/marketing-tools.png" alt="Marketing Tools">
                            <h4>Variety of Marketing Tools</h4>
                            <p>
                                Gain access to our selection of banners which are designed to fit all major IAB sizes, ready-to use text links, text ads to help you integrate our products into custom search results and pages, and email links.</p>
                        </div>
                        <div class="col-xs-12 col-sm-6 col-md-6 col-lg-3">
                            <img src="src/assets/images/lead-tracking-90-days.png" alt="Extended Lead Tracking">
                            <h4>Extended Lead Tracking</h4>
                            <p>
                                All leads sent to our site have a 90 day expiration tracked using cookies and IP address, meaning that even if they don’t make a sale today, you have up to 90 days for them to make a sale and earn commission.</p>
                        </div>
                        <div class="col-xs-12 col-sm-6 col-md-6 col-lg-3">
                            <img src="src/assets/images/real-time-reporting.png" alt="Real Time Reporting">
                            <h4>Real Time Statistics</h4>
                            <p>
                                See your affiliate performance statistics in real-time format as and when you need to. Track your leads and their transactions, your earnings data, how many visitors, see your payment thresholds, and more.</p>
                        </div>
                        <div class="col-xs-12 col-sm-6 col-md-6 col-lg-3">
                            <img src="src/assets/images/multi-tier-affiliate.png" alt="Multi-tier affiliate">
                            <h4>Multi-Tier Commission</h4>
                            <p>
                                If you have someone in your network that can also work as an affiliate, you can introduce them to the program through your special multi-tier link, and earn a commission on all sales they bring to Agent Legal.</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section class="section-4">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8 col-md-8 col-lg-offset-2 col-md-offset-2">
                        <h1>How it works</h1>
                    </div>
                </div>
                <div class="wrap-how">
                    <div class="row">
                        <div class="col-lg-2 col-md-2 col-sm-9 col-xs-12">
                            <img src="src/assets/images/drive-leads.png" alt="Drive Leads">
                            <h4>Use our marketing tools to drive leads</h4>
                        </div>
                        <div class="col-lg-2 col-md-2 col-arrow col-xs-12">
                            <img src="src/assets/images/arrow.png">
                        </div>
                        <div class="col-lg-2 col-md-2 col-sm-9 col-xs-12">
                            <img src="src/assets/images/leads-purchase.png" alt="Leads Purchase">
                            <h4>Your leads purchase from Agent Legal</h4>
                        </div>
                        <div class="col-lg-2 col-md-2 col-arrow col-xs-12">
                            <img src="src/assets/images/arrow.png">
                        </div>
                        <div class="col-lg-2 col-md-2 col-sm-9 col-xs-12">
                            <img src="src/assets/images/monitor-sales.png" alt="Monitor Sales">
                            <h4>Monitor your sales and commissions</h4>
                        </div>
                        <div class="col-lg-2 col-md-2 col-arrow col-xs-12">
                            <img src="src/assets/images/arrow.png">
                        </div>
                        <div class="col-lg-2 col-md-2 col-sm-9 col-xs-12">
                            <img src="src/assets/images/earnings.png" title="Earnings">
                            <h4>Withdraw your earnings to PayPal</h4>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section class="section-5">
            <div class="container">
                <div class="dot dot-grey">
                    <h3><span>Apply now to join our affiliate program</span><a :href="'/#/affiliates/signup'">
                        <button class="btn btn-green">Sign Up</button>
                    </a></h3>
                </div>
            </div>
        </section>
    </main>
</template>