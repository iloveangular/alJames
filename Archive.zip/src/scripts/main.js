export const API_KEY = "AIzaSyD0mwJPOZTK9oS5lyQqHoBPxwVQHkbs";
// export var url = 'http://localhost:3000/api/';
export var url = 'https://milosrest.herokuapp.com/api/';
export const AUTH_DOMAIN = "vuefirebasedemo.firebaseapp.com";
