<template>
    <section class="call-us">
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-sm-12 first">
                    <h4>Sign up to our Newsletters</h4>
                    <div class="block">
                        <div class="image"><img src="/src/assets/images/ccash.png"></div>
                        <div class="desc">
                            <h5>GET <span>10% DISCOUNT</span></h5>
                            <p>On your next purchase once subscribed</p>
                        </div>
                        <div class="button">
                            <button class="btn btn-green" type="button" data-toggle="modal" data-target="#exampleModal">
                                Subscribe
                            </button>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-12">
                    <h4>Need Assistance?</h4>
                    <div class="info">
                        <div class="image"><img src="/src/assets/images/cphone.png"></div>
                        <div class="desc">
                            <p>800.301.0052</p><span>Mon-Fri 8am-6pm EST</span></div>
                    </div>
                    <div class="info">
                        <div class="image"><img src="/src/assets/images/cmail.png"></div>
                        <div class="desc">
                            <p>support@agentlegal.com</p><span>1 business day response</span></div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</template>
