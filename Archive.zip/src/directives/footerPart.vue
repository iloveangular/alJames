<template>
    <main>
    <div class="call-us">
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-sm-12">
                    <h4>Sign up to our Newsletters</h4>
                    <div class="block">
                        <div class="image"><img src="/src/assets/images/ccash.png"></div>
                        <div class="desc">
                            <h5>GET <span>10% DISCOUNT</span></h5>
                            <p>On your next purchase once subscribed</p>
                        </div>
                        <div class="button">
                            <button class="btn btn-green btn-large" type="button" data-toggle="modal" data-target="#exampleModal">
                                Subscribe
                            </button>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-12 first">
                    <h4>Need Assistance?</h4>
                    <div class="info">
                        <div class="image"><img src="/src/assets/images/cphone.png"></div>
                        <div class="desc">
                            <p>800.301.0052</p><span>Mon-Fri 8am-6pm EST</span></div>
                    </div>
                    <div class="info">
                        <div class="image"><img src="/src/assets/images/cmail.png"></div>
                        <div class="desc">
                            <p>support@agentlegal.com</p><span>1 business day response</span></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
        <footer>
            <div class="container"><img src="/src/assets/images/logo.png" class="footer-logo">
                <ul>
                    <li><a href="/#/about">About</a></li>
                    <li><a href="/#/affiliates">Affiliates</a></li>
                    <li><a href="/#/contact">Contact</a></li>
                    <li><a href="/#/disclaimer">Disclaimer</a></li>
                    <li><a href="/#/partners">Partners</a></li>
                    <li><a href="/#/faqs">FAQ</a></li>
                    <li><a href="/#/privacy-policy">Privacy Policy</a></li>
                    <li><a href="/#/terms">Terms of Business</a></li>
                    <li><a href="/#/terms-of-use">Terms of Use</a></li>
                </ul>
                <div class="logos">
                    <div class="social-links">
                        <a href="#"><img src="/src/assets/images/facebook.png"></a>
                        <a href="#"><img src="/src/assets/images/twitter.png"></a>
                        <a href="#"><img src="/src/assets/images/google.png"></a>
                    </div>
                    <div class="other-logos">
                        <a href="#"><img src="/src/assets/images/trust.png"></a>
                        <a href="#"><img src="/src/assets/images/pci.png"></a>
                        <a href="#"><img src="/src/assets/images/verified.png"></a>
                        <a href="#"><img src="/src/assets/images/paypal.png"></a>
                        <a href="#"><img src="/src/assets/images/mastercard.png"></a>
                        <a href="#" class="card-dekatop"><img src="/src/assets/images/cards.png"></a>
                    </div>
                    <div style="display: none;" class="other-logos-small">
                        <a href="#"><img src="/src/assets/images/verified.png"></a>
                        <a href="#"><img src="/src/assets/images/paypal.png"></a>
                        <a href="#"><img src="/src/assets/images/mastercard.png"></a>
                        <a href="#"><img src="/src/assets/images/bitcoin.png"></a>
                        <a href="#"><img style=" width: 165px;" src="/src/assets/images/pci.png"></a>
                    </div>
                </div>
                <p>© 2018 Agent Legal, LLC. All rights reserved. Agent Legal and AgentLegal are registered trademarks of
                    Agent Legal, LLC.</p>
            </div>
        </footer>
    </main>
</template>
